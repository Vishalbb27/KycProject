import logging
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.router import api_router
from app.core.exceptions import DocumentQualityError, BaseAppException

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("kyc_backend")

app = FastAPI(
    title="KYC Onboarding & Verification API",
    description="Production-grade Azure & FastAPI backend for identity verification.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.exception_handler(DocumentQualityError)
async def document_quality_handler(request: Request, exc: DocumentQualityError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"success": False, "error": {"code": "DOCUMENT_QUALITY_FAILURE", "message": exc.detail}}
    )

@app.exception_handler(BaseAppException)
async def custom_app_exception_handler(request: Request, exc: BaseAppException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": {"code": exc.error_code, "message": exc.detail}}
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled Internal Server Error", exc_info=exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "error": {"code": "INTERNAL_SERVER_ERROR", "message": "An unexpected error occurred. Please try again."}}
    )

# ... existing app = FastAPI(...) setup ...
# ... exception handlers ...

# --- LOCAL AUTH BYPASS FOR TESTING ---
from app.api.deps import get_current_user_token

async def mock_token_payload():
    return {
        "preferred_username": "rahul@example.com", 
        "name": "Rahul Sharma",
        "oid": "mock-object-id-12345"
    }

app.dependency_overrides[get_current_user_token] = mock_token_payload
# -------------------------------------

app.include_router(api_router, prefix="/api/v1")

app.include_router(api_router, prefix="/api/v1")