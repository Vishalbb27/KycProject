import hashlib
from azure.storage.blob import ContentSettings
from azure.storage.blob.aio import BlobServiceClient
from fastapi import HTTPException, status
from app.core.config import settings

class AzureBlobService:
    def __init__(self):
        self.client = BlobServiceClient.from_connection_string(settings.AZURE_STORAGE_CONNECTION_STRING)
        self.container_name = settings.AZURE_BLOB_CONTAINER

    def calculate_hash(self, content: bytes) -> str:
        return hashlib.sha256(content).hexdigest()

    async def upload_document_pdf(self, file_content: bytes, destination_path: str) -> str:
        try:
            container_client = self.client.get_container_client(self.container_name)
            blob_client = container_client.get_blob_client(destination_path)
            
            # Use ContentSettings object instead of a dict
            content_settings = ContentSettings(content_type="application/pdf")
            
            await blob_client.upload_blob(
                file_content, 
                overwrite=True, 
                content_settings=content_settings
            )
            return destination_path
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"Failed to upload document to Azure Blob Storage: {str(e)}"
            )

    async def close(self):
        await self.client.close()