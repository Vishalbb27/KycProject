// postcss.config.js (in the root of your project)
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}