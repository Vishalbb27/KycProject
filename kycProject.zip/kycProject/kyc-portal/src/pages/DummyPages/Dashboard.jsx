import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, ShieldCheck } from 'lucide-react';
import { useMsal } from '@azure/msal-react';

export default function Dashboard() {
  const { accounts } = useMsal();
  const displayName = accounts.length > 0 ? accounts[0].name.split(' ')[0] : "Arjun";

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-8 rounded-2xl shadow-sm flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome back, {displayName}!</h1>
          <p className="text-blue-100">Complete your KYC verification to unlock full banking and platform features.</p>
        </div>
        <Link to="/customer/kyc" className="bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50 transition shadow">
          Continue KYC →
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-500 font-medium">KYC Status</span>
            <span className="bg-yellow-100 text-yellow-800 text-xs px-2.5 py-1 rounded-full font-semibold">In Progress</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">Step 2 of 6</p>
          <p className="text-sm text-gray-500 mt-1">Document Upload Active</p>
        </div>

        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-500 font-medium">Verified Documents</span>
            <FileText className="text-blue-600" size={20} />
          </div>
          <p className="text-2xl font-bold text-gray-800">2 / 2</p>
          <p className="text-sm text-gray-500 mt-1">Identity & Address Proof</p>
        </div>

        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-500 font-medium">Security Level</span>
            <ShieldCheck className="text-green-600" size={20} />
          </div>
          <p className="text-2xl font-bold text-gray-800">High</p>
          <p className="text-sm text-gray-500 mt-1">Encrypted & Compliant</p>
        </div>
      </div>
    </div>
  );
}