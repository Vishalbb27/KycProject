import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, AlertTriangle, ShieldCheck, Download } from 'lucide-react';

export default function CaseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Info */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/investigator/cases')} className="text-gray-500 hover:text-gray-800"><ArrowLeft /></button>
          <h1 className="text-2xl font-bold text-gray-800">{id}</h1>
          <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">Completed</span>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border rounded bg-white text-gray-700">Reprocess AI</button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Assign to Me</button>
        </div>
      </div>

      {/* Customer Info Bar */}
      <div className="bg-white p-6 rounded-lg shadow-sm border flex items-center gap-6">
        <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-2xl font-bold">AM</div>
        <div className="grid grid-cols-4 flex-1 gap-4 text-sm">
          <div>
            <p className="text-gray-500">Customer Name</p>
            <p className="font-semibold text-gray-900 flex items-center">Arjun Mehta <CheckCircle size={14} className="text-green-500 ml-1"/></p>
          </div>
          <div><p className="text-gray-500">Date of Birth</p><p className="font-medium">15 May 1990</p></div>
          <div><p className="text-gray-500">Gender</p><p className="font-medium">Male</p></div>
          <div><p className="text-gray-500">Email</p><p className="font-medium text-blue-600">arjun.mehta@example.com</p></div>
        </div>
        <div className="border-l pl-6">
           <div className="text-sm text-center">
             <p className="text-gray-500 mb-1">AI Confidence</p>
             <p className="text-2xl font-bold text-green-600">96.4%</p>
           </div>
        </div>
      </div>

      {/* AI Assessment Panel */}
      <div className="bg-green-50 border border-green-200 p-6 rounded-lg flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center"><ShieldCheck size={28}/></div>
          <div>
            <h3 className="font-bold text-green-900 text-lg">IDENTITY VERIFIED</h3>
            <p className="text-sm text-green-800">Customer identity has been successfully verified based on the available evidence.</p>
          </div>
        </div>
        <div className="flex gap-8">
          <div className="text-center">
            <p className="text-xs text-gray-500 uppercase font-bold">Recommendation</p>
            <p className="text-lg font-bold text-green-600">APPROVE</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 uppercase font-bold">Risk Level</p>
            <p className="text-lg font-bold text-green-600 bg-green-100 px-3 py-1 rounded mt-1">LOW</p>
          </div>
        </div>
      </div>

      {/* Investigator Decision Form */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="font-bold text-lg mb-4">Investigator Decision</h3>
        <div className="flex gap-6 items-start">
          <div className="space-y-3">
            <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="decision" value="approve" className="w-4 h-4 text-blue-600"/> Approve</label>
            <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="decision" value="reject" className="w-4 h-4 text-blue-600"/> Reject</label>
            <label className="flex items-center gap-2 cursor-pointer"><input type="radio" name="decision" value="refer" className="w-4 h-4 text-blue-600"/> Refer</label>
          </div>
          <div className="flex-1">
             <textarea className="w-full border rounded-lg p-3 text-sm h-24 bg-gray-50 focus:bg-white focus:outline-blue-500" placeholder="Enter remarks..."></textarea>
          </div>
          <div className="flex flex-col gap-3 min-w-[200px]">
             <select className="border rounded p-2 text-sm bg-gray-50"><option>Assign To: John Doe (Me)</option></select>
             <button className="bg-blue-600 text-white font-medium py-2 rounded shadow hover:bg-blue-700">Save Decision</button>
          </div>
        </div>
      </div>
    </div>
  );
}