import React from 'react';

export default function InvestigatorDashboard() {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-800">Investigator Overview</h1>
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <p className="text-gray-500 text-sm">Total Cases</p>
          <p className="text-3xl font-bold text-gray-800 mt-2">248</p>
        </div>
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <p className="text-gray-500 text-sm">Pending Review</p>
          <p className="text-3xl font-bold text-yellow-600 mt-2">18</p>
        </div>
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <p className="text-gray-500 text-sm">Approved Today</p>
          <p className="text-3xl font-bold text-green-600 mt-2">42</p>
        </div>
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <p className="text-gray-500 text-sm">Flagged / Rejected</p>
          <p className="text-3xl font-bold text-red-600 mt-2">5</p>
        </div>
      </div>
    </div>
  );
}