import React from 'react';

export default function Configuration() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-4">Portal Configuration</h1>
      <div className="bg-white p-6 rounded-xl border shadow-sm space-y-4">
        <h3 className="font-semibold text-lg">AI Confidence Thresholds</h3>
        <label className="block text-sm text-gray-600">
          Auto-Approval Cutoff: <input type="number" defaultValue={95} className="ml-2 border rounded p-1 w-20" /> %
        </label>
      </div>
    </div>
  );
}