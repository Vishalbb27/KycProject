import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, Download } from 'lucide-react';

export default function Cases() {
  const navigate = useNavigate();
  
  // Dummy Data for Investigator
  const cases = [
    { id: 'KYC-2026-000123', name: 'Arjun Mehta', type: 'New', source: 'Manual', status: 'Completed', aiScore: '96.4%', risk: 'Low', date: '04 Oct 2026' },
    { id: 'KYC-2025-001233', name: 'Priya Mehta', type: 'Renewal', source: 'DigiLocker', status: 'New', aiScore: '91.2%', risk: 'Medium', date: '05 Jan 2025' },
    // Add more mock items here
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">KYC Cases</h1>
        <button className="flex items-center px-4 py-2 bg-white border rounded shadow-sm text-gray-600"><Download size={16} className="mr-2"/> Export</button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border p-4">
        {/* Filters */}
        <div className="flex gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            <input type="text" placeholder="Search customer name, KYC ID..." className="w-full pl-10 pr-4 py-2 border rounded bg-gray-50" />
          </div>
          {/* Add Dropdowns for Status, Type, etc. here */}
        </div>

        {/* Data Table */}
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 text-gray-600 border-y">
              <th className="p-3 font-medium">KYC ID</th>
              <th className="p-3 font-medium">Customer Name</th>
              <th className="p-3 font-medium">Status</th>
              <th className="p-3 font-medium">AI Confidence</th>
              <th className="p-3 font-medium">Risk Level</th>
              <th className="p-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {cases.map((c, idx) => (
              <tr key={idx} className="border-b hover:bg-gray-50">
                <td className="p-3 text-blue-600 cursor-pointer" onClick={() => navigate(`/investigator/cases/${c.id}`)}>{c.id}</td>
                <td className="p-3">{c.name}</td>
                <td className="p-3"><span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">{c.status}</span></td>
                <td className="p-3">{c.aiScore}</td>
                <td className="p-3"><span className="px-2 py-1 bg-green-50 text-green-700 text-xs rounded border border-green-200">{c.risk}</span></td>
                <td className="p-3 text-blue-600 cursor-pointer" onClick={() => navigate(`/investigator/cases/${c.id}`)}>Edit</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}