import React from 'react';

export default function Reports() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-4">KYC Compliance Reports</h1>
      <div className="bg-white p-8 rounded-xl border shadow-sm text-center text-gray-500">
        Analytics and automated audit reporting modules will load here.
      </div>
    </div>
  );
}