import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { KycContext } from '../context/KycContext';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../authConfig';

export default function Login() {
  const navigate = useNavigate();
  const { updateKycData } = useContext(KycContext);
  const { instance } = useMsal();

  const handleLogin = async (type) => {
    try {
      if (type === 'msal') {
        // 1. Trigger the Microsoft Login
        const loginResponse = await instance.loginPopup(loginRequest);
        
        // 2. Grab the real JWT token
        const tokenResponse = await instance.acquireTokenSilent({
          ...loginRequest,
          account: loginResponse.account
        });

        console.log("MSAL Login successful. Token acquired:", tokenResponse.accessToken);
        
        const realToken = tokenResponse.accessToken;
        const loggedInName = loginResponse.account.name;

        // 3. Call your FastAPI backend with the REAL token
        // 3. Call your FastAPI backend with the absolute URL
        const response = await fetch('/api/v1/cases/init', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${realToken}` 
          }
        });

        if (!response.ok) {
          throw new Error(`Server error: ${response.status}`);
        }

        const resData = await response.json();
        
        updateKycData({ 
          caseId: resData.data.KycCaseId, 
          step: 1, 
          userName: loggedInName 
        });
        
        navigate('/customer/kyc');
      }
    } catch (err) {
      console.error("MSAL Authentication failed", err);
      instance.clearCache();
      alert("Login failed. Check console for details.");
    }
  };

  return (
    <div className="flex h-screen items-center justify-center bg-gray-50">
      <div className="p-8 bg-white shadow-xl rounded-2xl w-96 border border-gray-100 text-center">
        <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
          C
        </div>
        <h2 className="text-2xl font-bold mb-1 text-gray-800">Portal Login</h2>
        <p className="text-sm text-gray-500 mb-6">Authenticate via MSAL or testing modes.</p>
        
        <button 
          onClick={() => handleLogin('msal')}
          className="w-full bg-blue-600 text-white py-2.5 rounded-xl font-medium mb-4 hover:bg-blue-700 transition shadow-sm"
        >
          Login with MSAL (Redirect)
        </button>
        
        <div className="relative flex py-2 items-center mb-4">
          <div className="flex-grow border-t border-gray-200"></div>
          <span className="flex-shrink mx-4 text-gray-400 text-xs uppercase tracking-wider">or test mode</span>
          <div className="flex-grow border-t border-gray-200"></div>
        </div>

        <button 
          onClick={() => handleLogin('dummy')}
          className="w-full bg-gray-100 text-gray-700 py-2.5 rounded-xl font-medium mb-3 hover:bg-gray-200 transition"
        >
          Dummy Login (Customer)
        </button>
        <button 
          onClick={() => handleLogin('investigator')}
          className="w-full bg-slate-900 text-white py-2.5 rounded-xl font-medium hover:bg-slate-800 transition"
        >
          Dummy Login (Investigator)
        </button>
      </div>
    </div>
  );
}