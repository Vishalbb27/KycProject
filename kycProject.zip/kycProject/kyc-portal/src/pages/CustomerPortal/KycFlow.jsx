import React, { useContext } from 'react';
import { KycContext } from '../../context/KycContext';
import ChooseMethod from './Steps/ChooseMethod';
import UploadDocuments from './Steps/UploadDocuments';
import ReviewConsent from './Steps/ReviewConsent';
import Biometric from './Steps/Biometric';
import FinalReview from './Steps/FinalReview';
import Processing from './Steps/Processing';
import { Check } from 'lucide-react';

export default function KycFlow() {
  const { kycData, updateKycData } = useContext(KycContext);
  const currentStep = kycData.step;

  const steps = [
    { num: 1, label: 'Choose Method' },
    { num: 2, label: 'Upload Documents' },
    { num: 3, label: 'Review & Consent' },
    { num: 4, label: 'Biometric Verification' },
    { num: 5, label: 'Final Review & Submit' },
    { num: 6, label: 'Processing' },
  ];

  const nextStep = () => updateKycData({ step: Math.min(currentStep + 1, 6) });
  const prevStep = () => updateKycData({ step: Math.max(currentStep - 1, 1) });

  return (
    <div className="max-w-7xl mx-auto">
      {/* Stepper */}
      <div className="mb-8 bg-white p-4 rounded-lg shadow-sm flex justify-between items-center relative">
        <div className="absolute left-10 right-10 top-1/2 h-0.5 bg-gray-200 -z-10"></div>
        <div className="absolute left-10 right-10 top-1/2 h-0.5 bg-green-500 -z-10" style={{ width: `${((currentStep - 1) / 5) * 100}%` }}></div>
        
        {steps.map((step) => (
          <div key={step.num} className="flex flex-col items-center bg-white px-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold mb-2 ${
              currentStep > step.num ? 'bg-green-500 text-white' : 
              currentStep === step.num ? 'bg-blue-600 text-white ring-4 ring-blue-100' : 
              'bg-gray-200 text-gray-500'
            }`}>
              {currentStep > step.num ? <Check size={16} /> : step.num}
            </div>
            <span className={`text-sm ${currentStep === step.num ? 'text-gray-900 font-semibold' : 'text-gray-500'}`}>
              {step.label}
            </span>
          </div>
        ))}
      </div>

      {/* Step Content */}
      <div className="mt-6">
        {currentStep === 1 && <ChooseMethod nextStep={nextStep} />}
        {currentStep === 2 && <UploadDocuments nextStep={nextStep} prevStep={prevStep} />}
        {currentStep === 3 && <ReviewConsent nextStep={nextStep} prevStep={prevStep} />}
        {currentStep === 4 && <Biometric nextStep={nextStep} prevStep={prevStep} />}
        {currentStep === 5 && <FinalReview nextStep={nextStep} prevStep={prevStep} />}
        {currentStep === 6 && <Processing />}
      </div>
    </div>
  );
}