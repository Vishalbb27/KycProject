import React from 'react';

export default function Applications() {
  return (
    <div className="p-6 bg-white rounded-xl shadow-sm border max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">My Applications</h1>
      <p className="text-gray-500 mb-6">Track the history and status of all your submitted KYC applications.</p>
      <div className="border rounded-lg p-6 text-center text-gray-500 bg-gray-50">
        No past applications found. Active KYC is currently in progress.
      </div>
    </div>
  );
}