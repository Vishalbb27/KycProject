import React from 'react';

export default function Support() {
  return (
    <div className="p-6 bg-white rounded-xl shadow-sm border max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Customer Support</h1>
      <p className="text-gray-500 mb-6">Facing issues with document uploads or biometric checks? Reach out below.</p>
      <div className="p-6 bg-gray-50 rounded-lg border max-w-md">
        <p className="font-semibold text-gray-800 mb-2">Help Desk Hotline</p>
        <p className="text-blue-600 font-bold text-lg mb-4">1800-KYC-SUPPORT</p>
        <p className="text-sm text-gray-500">Email: support@company.com</p>
      </div>
    </div>
  );
}