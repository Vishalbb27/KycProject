import React from 'react';

export default function Documents() {
  return (
    <div className="p-6 bg-white rounded-xl shadow-sm border max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Vault Documents</h1>
      <p className="text-gray-500 mb-6">Manage all documents uploaded across your verified sessions.</p>
      <div className="border rounded-lg p-6 text-center text-gray-500 bg-gray-50">
        Uploaded documents will appear here once processed.
      </div>
    </div>
  );
}