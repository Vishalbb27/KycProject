import React, { useEffect, useState } from 'react';
import { CheckCircle, Settings, Loader2 } from 'lucide-react';

export default function Processing() {
  const [progress, setProgress] = useState(20);

  // Mocking the polling API for state persistence and progress
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 20;
      });
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex gap-6">
      <div className="flex-1 bg-white p-10 rounded-lg shadow-sm text-center">
        <h2 className="text-3xl font-bold mb-2">KYC Submission in Progress</h2>
        <p className="text-gray-500 mb-8">Your application has been submitted successfully. We are now processing your KYC.</p>
        
        <div className="flex justify-center mb-6">
          <div className="relative w-32 h-32 flex items-center justify-center border-4 border-blue-100 rounded-full">
             <Loader2 size={48} className="text-blue-600 animate-spin" />
             <div className="absolute inset-0 border-4 border-blue-600 rounded-full animate-pulse opacity-50" style={{ clipPath: `inset(0 ${100-progress}% 0 0)` }}></div>
          </div>
        </div>
        
        <h3 className="text-xl font-bold mb-2">Processing Your KYC</h3>
        <p className="text-gray-500 mb-6">Estimated time: 2-5 minutes</p>

        <div className="max-w-md mx-auto text-left space-y-4">
          <div className="flex items-center text-sm"><CheckCircle className="text-green-500 mr-3"/> Application Submitted <span className="ml-auto text-green-500">Completed</span></div>
          <div className="flex items-center text-sm"><CheckCircle className="text-green-500 mr-3"/> Document Verification <span className="ml-auto text-green-500">Completed</span></div>
          <div className="flex items-center text-sm"><CheckCircle className="text-green-500 mr-3"/> Biometric Verification <span className="ml-auto text-green-500">Completed</span></div>
          <div className={`flex items-center text-sm ${progress < 80 ? 'text-blue-600' : ''}`}>
            {progress >= 80 ? <CheckCircle className="text-green-500 mr-3"/> : <Settings className="animate-spin mr-3"/>} 
            External Verification <span className={`ml-auto ${progress < 80 ? 'text-blue-600' : 'text-green-500'}`}>{progress >= 80 ? 'Completed' : 'In Progress'}</span>
          </div>
        </div>
      </div>
      
      {/* Right Sidebar */}
      <div className="w-80 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
        <h4 className="font-bold text-lg mb-6">What happens next?</h4>
        <div className="space-y-6">
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold shrink-0">1</div>
            <p className="text-sm text-gray-600">We verify your documents with government databases and authorized sources.</p>
          </div>
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold shrink-0">2</div>
            <p className="text-sm text-gray-600">Our team may perform additional checks if required.</p>
          </div>
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold shrink-0">3</div>
            <p className="text-sm text-gray-600">You will be notified once the verification is complete.</p>
          </div>
        </div>
      </div>
    </div>
  );
}