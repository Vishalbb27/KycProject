import React, { useContext } from 'react';
import { KycContext } from '../../../context/KycContext';
import { CheckCircle, FileText, ShieldCheck, Edit2, Upload, Lock } from 'lucide-react';

export default function FinalReview({ nextStep, prevStep }) {
  const { kycData, updateKycData } = useContext(KycContext);

  const handleSubmitKyc = async () => {
    // API SUBMISSION MOCK
    
    // try {
    //   const response = await fetch('/api/v1/cases/submit', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ case_id: kycData.caseId })
    //   });
    //   const result = await response.json();
    //   if (result.success) {
    //     nextStep(); // Moves to step 6 (Processing / Polling)
    //   }
    // } catch (error) {
    //   console.error('Submission failed', error);
    // }
    
    
    // Proceed to Step 6 (Processing)
    nextStep();
  };

  const jumpToStep = (stepNumber) => {
    updateKycData({ step: stepNumber });
  };

  return (
    <div className="flex gap-6 max-w-7xl mx-auto">
      {/* Main Content Area */}
      <div className="flex-1 space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-2xl font-bold mb-2 text-gray-800">Final Review & Submit</h2>
          <p className="text-gray-500 mb-6">Please review all the information below before submitting your KYC. You can go back and edit if needed.</p>

          {/* 1. Personal Information Section */}
          <div className="mb-6 border rounded-lg p-5 bg-gray-50/50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold flex items-center text-lg text-gray-800">
                <FileText className="mr-2 text-blue-600" size={20} /> Personal Information <span className="text-xs ml-2 text-green-600 bg-green-100 px-2 py-0.5 rounded-full font-medium">Verified</span>
              </h3>
              <button onClick={() => jumpToStep(2)} className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                <Edit2 size={14} className="mr-1" /> Edit
              </button>
            </div>
            <div className="grid grid-cols-2 gap-y-3 text-sm">
              <div><span className="text-gray-500">Full Name:</span> <span className="font-medium ml-2">Arjun Mehta</span></div>
              <div><span className="text-gray-500">Nationality:</span> <span className="font-medium ml-2">Indian</span></div>
              <div><span className="text-gray-500">Date of Birth:</span> <span className="font-medium ml-2">15 May 1990</span></div>
              <div><span className="text-gray-500">Identity Number:</span> <span className="font-medium ml-2">[ID Number Redacted]</span></div>
              <div><span className="text-gray-500">Gender:</span> <span className="font-medium ml-2">Male</span></div>
              <div><span className="text-gray-500">Enrolment ID:</span> <span className="font-medium ml-2">1234 5678 9012</span></div>
            </div>
          </div>

          {/* 2. Address Information Section */}
          <div className="mb-6 border rounded-lg p-5 bg-gray-50/50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold flex items-center text-lg text-gray-800">
                <FileText className="mr-2 text-blue-600" size={20} /> Address Information <span className="text-xs ml-2 text-green-600 bg-green-100 px-2 py-0.5 rounded-full font-medium">Verified</span>
              </h3>
              <button onClick={() => jumpToStep(2)} className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                <Edit2 size={14} className="mr-1" /> Edit
              </button>
            </div>
            <div className="grid grid-cols-2 gap-y-3 text-sm">
              <div><span className="text-gray-500">Address:</span> <span className="font-medium ml-2">123 MG Road, Sector 15, Gurugram, Haryana - 122001</span></div>
              <div><span className="text-gray-500">Document Type:</span> <span className="font-medium ml-2">Passport</span></div>
              <div><span className="text-gray-500">Country:</span> <span className="font-medium ml-2">India</span></div>
              <div><span className="text-gray-500">Document Number:</span> <span className="font-medium ml-2">N1234567</span></div>
            </div>
          </div>

          {/* 3. Biometric Verification Section */}
          <div className="mb-6 border rounded-lg p-5 bg-gray-50/50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold flex items-center text-lg text-gray-800">
                <ShieldCheck className="mr-2 text-blue-600" size={20} /> Biometric Verification <span className="text-xs ml-2 text-green-600 bg-green-100 px-2 py-0.5 rounded-full font-medium">Completed</span>
              </h3>
            </div>
            <div className="flex items-center gap-6">
              {kycData.biometric ? (
                <img src={kycData.biometric} alt="Captured Selfie" className="w-16 h-16 rounded-full object-cover border" />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center text-xs text-gray-500">No Image</div>
              )}
              <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm flex-1">
                <div className="flex items-center text-green-700"><CheckCircle size={14} className="mr-2 text-green-500" /> Liveness Detection: <span className="font-semibold ml-1">Successful</span></div>
                <div className="flex items-center text-green-700"><CheckCircle size={14} className="mr-2 text-green-500" /> Face Match: <span className="font-semibold ml-1">98.6% Match</span></div>
                <div className="flex items-center text-green-700"><CheckCircle size={14} className="mr-2 text-green-500" /> Anti-Spoofing: <span className="font-semibold ml-1">Passed</span></div>
                <div className="flex items-center text-green-700"><CheckCircle size={14} className="mr-2 text-green-500" /> Quality Check: <span className="font-semibold ml-1">Passed</span></div>
              </div>
            </div>
          </div>

          {/* Step Actions */}
          <div className="flex justify-between mt-6 pt-4 border-t">
            <button onClick={prevStep} className="px-6 py-2 border rounded-lg hover:bg-gray-50 font-medium">Back</button>
            <button onClick={handleSubmitKyc} className="px-8 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold shadow-sm">Submit KYC →</button>
          </div>
        </div>
      </div>

      {/* Right Information Sidebar */}
      <div className="w-80 space-y-6">
        {/* Uploaded Documents Quick Preview */}
        <div className="bg-white p-5 rounded-lg shadow-sm border">
          <h4 className="font-bold text-base mb-4 flex items-center justify-between">
            Uploaded Documents
            <button onClick={() => jumpToStep(2)} className="text-blue-600 text-xs flex items-center"><Edit2 size={12} className="mr-1"/> Edit</button>
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded border">
              <span className="font-medium text-gray-700">Personal ID (Front)</span>
              <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded">Processed</span>
            </div>
            <div className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded border">
              <span className="font-medium text-gray-700">Personal ID (Back)</span>
              <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded">Processed</span>
            </div>
            <div className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded border">
              <span className="font-medium text-gray-700">Address Proof (Front)</span>
              <span className="text-xs text-green-600 bg-green-100 px-2 py-0.5 rounded">Processed</span>
            </div>
          </div>
        </div>

        {/* Declarations & Consent */}
        <div className="bg-blue-50 p-5 rounded-lg border border-blue-100">
          <h4 className="font-bold mb-3 text-blue-900 text-sm">Declarations & Consent</h4>
          <div className="space-y-3 text-xs text-blue-900">
            <label className="flex items-start cursor-pointer">
              <input type="checkbox" defaultChecked className="mt-0.5 mr-2 shrink-0" />
              I confirm that all information provided is correct and accurate.
            </label>
            <label className="flex items-start cursor-pointer">
              <input type="checkbox" defaultChecked className="mt-0.5 mr-2 shrink-0" />
              I consent to the use of my documents and biometric data for KYC verification.
            </label>
            <label className="flex items-start cursor-pointer">
              <input type="checkbox" defaultChecked className="mt-0.5 mr-2 shrink-0" />
              I authorize the verification of my details with government databases.
            </label>
          </div>
        </div>

        {/* Ready to Submit Card */}
        <div className="bg-green-50 p-5 rounded-lg border border-green-200">
          <div className="flex items-start">
            <CheckCircle className="text-green-600 mr-3 shrink-0 mt-0.5" size={20} />
            <div>
              <h5 className="font-bold text-green-900 text-sm">Ready to Submit</h5>
              <p className="text-xs text-green-700 mt-1">All required information and verifications are complete. Click Submit to complete your KYC.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}