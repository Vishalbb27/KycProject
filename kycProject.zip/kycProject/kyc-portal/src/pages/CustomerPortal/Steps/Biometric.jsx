import React, { useRef, useCallback, useContext } from 'react';
import Webcam from 'react-webcam';
import { KycContext } from '../../../context/KycContext';

export default function Biometric({ nextStep, prevStep }) {
  const webcamRef = useRef(null);
  const { kycData, updateKycData } = useContext(KycContext);

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    updateKycData({ biometric: imageSrc });
  }, [webcamRef, updateKycData]);

  return (
    <div className="flex gap-6">
      <div className="flex-1 bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-bold mb-6">Biometric Verification</h2>
        
        <div className="flex flex-col items-center bg-gray-50 p-6 rounded-lg border">
          {kycData.biometric ? (
            <img src={kycData.biometric} alt="Face captured" className="rounded-lg mb-4 h-64 object-cover" />
          ) : (
            <Webcam
              audio={false}
              ref={webcamRef}
              screenshotFormat="image/png"
              className="rounded-lg mb-4 h-64 object-cover"
            />
          )}
          
          {!kycData.biometric ? (
            <button onClick={capture} className="bg-blue-600 text-white px-6 py-2 rounded">Capture Face</button>
          ) : (
            <button onClick={() => updateKycData({ biometric: null })} className="bg-gray-200 text-gray-800 px-6 py-2 rounded">Retake</button>
          )}
        </div>

        <div className="flex justify-between mt-6">
          <button onClick={prevStep} className="px-6 py-2 border rounded">Back</button>
          <button onClick={nextStep} disabled={!kycData.biometric} className="px-6 py-2 bg-blue-600 text-white rounded disabled:opacity-50">Next →</button>
        </div>
      </div>
    </div>
  );
}