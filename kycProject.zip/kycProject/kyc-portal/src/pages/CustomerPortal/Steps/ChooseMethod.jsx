import React from 'react';
import { Building2, Cloud, FileUp, ShieldCheck, Zap, Unlock, Lock, Check } from 'lucide-react';

export default function ChooseMethod({ nextStep }) {
  return (
    <div className="flex gap-6">
      <div className="flex-1 bg-white p-8 rounded-lg shadow-sm">
        <h2 className="text-3xl font-bold mb-2 text-gray-800">Complete Your KYC / eKYC</h2>
        <p className="text-gray-500 mb-8 text-lg">Choose how you want to complete your KYC. You can fetch your details from government sources or upload your documents manually.</p>
        
        <div className="grid grid-cols-3 gap-6 mb-8">
          {/* CKYC (Disabled) */}
          <div className="border border-gray-200 rounded-xl p-6 opacity-60 bg-gray-50">
             <div className="text-center mb-4 text-blue-300">
               <Building2 size={48} className="mx-auto" />
             </div>
             <h3 className="text-xl font-semibold text-center mb-2">CKYC</h3>
             <p className="text-sm text-center text-gray-500 mb-6">Fetch your KYC details from Central KYC Registry (CKYC)</p>
             <ul className="text-sm space-y-2 text-gray-600 mb-6">
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Quick and hassle-free</li>
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Auto fetches your verified details</li>
             </ul>
             <button disabled className="w-full py-2 bg-gray-200 text-gray-500 rounded font-medium">Currently Unavailable</button>
          </div>

          {/* DigiLocker (Disabled) */}
          <div className="border border-gray-200 rounded-xl p-6 opacity-60 bg-gray-50">
             <div className="text-center mb-4 text-purple-300">
               <Cloud size={48} className="mx-auto" />
             </div>
             <h3 className="text-xl font-semibold text-center mb-2">DigiLocker</h3>
             <p className="text-sm text-center text-gray-500 mb-6">Fetch your documents from DigiLocker</p>
             <ul className="text-sm space-y-2 text-gray-600 mb-6">
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Secure and verified documents</li>
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Faster KYC completion</li>
             </ul>
             <button disabled className="w-full py-2 bg-gray-200 text-gray-500 rounded font-medium">Currently Unavailable</button>
          </div>

          {/* Manual Upload (Active) */}
          <div className="border-2 border-blue-500 rounded-xl p-6 bg-blue-50 relative cursor-pointer" onClick={nextStep}>
             <div className="text-center mb-4 text-blue-600">
               <FileUp size={48} className="mx-auto" />
             </div>
             <h3 className="text-xl font-semibold text-center mb-2 text-blue-900">Manual Upload</h3>
             <p className="text-sm text-center text-blue-800 mb-6">Upload your documents manually</p>
             <ul className="text-sm space-y-2 text-blue-800 mb-6">
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Upload files from your device</li>
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> Supports strictly PNG</li>
               <li className="flex items-center"><Check size={16} className="text-green-500 mr-2"/> We will verify your documents</li>
             </ul>
             <button className="w-full py-2 bg-blue-600 text-white rounded font-medium hover:bg-blue-700">Select & Continue</button>
          </div>
        </div>
      </div>

      {/* Right Sidebar */}
      <div className="w-80 space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <h3 className="font-bold text-lg mb-4 text-gray-800">Why complete KYC?</h3>
          <div className="space-y-4">
            <div className="flex">
              <ShieldCheck className="text-green-500 mr-3 shrink-0" size={24} />
              <div>
                <h4 className="font-semibold text-sm">Secure and compliant process</h4>
                <p className="text-xs text-gray-500">Your data is protected and encrypted</p>
              </div>
            </div>
            <div className="flex">
              <Zap className="text-blue-500 mr-3 shrink-0" size={24} />
              <div>
                <h4 className="font-semibold text-sm">Faster onboarding</h4>
                <p className="text-xs text-gray-500">Complete your KYC in minutes</p>
              </div>
            </div>
            <div className="flex">
              <Unlock className="text-orange-500 mr-3 shrink-0" size={24} />
              <div>
                <h4 className="font-semibold text-sm">Access all services</h4>
                <p className="text-xs text-gray-500">Unlock full benefits and features</p>
              </div>
            </div>
            <div className="flex">
              <Lock className="text-yellow-500 mr-3 shrink-0" size={24} />
              <div>
                <h4 className="font-semibold text-sm">Your information is safe</h4>
                <p className="text-xs text-gray-500">We follow strict security standards</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}