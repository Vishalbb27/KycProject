import React, { useContext } from 'react';
import { KycContext } from '../../../context/KycContext';
import { CheckCircle, FileText, Home as HomeIcon } from 'lucide-react';

export default function ReviewConsent({ nextStep, prevStep }) {
  const { kycData } = useContext(KycContext);
  
  // Retrieve documents and extracted data from global state
  const personalDoc = kycData.documents?.personalId || {};
  const addressDoc = kycData.documents?.addressProof || {};
  
  const personalInfo = kycData.extractedInfo?.personalId || {};
  const addressInfo = kycData.extractedInfo?.addressProof || {};

  const personalExtracted = personalInfo.extractedData || {};
  const addressExtracted = addressInfo.extractedData || {};

  return (
    <div className="flex gap-6 max-w-7xl mx-auto">
      <div className="flex-1 bg-white p-8 rounded-xl shadow-sm border">
        <h2 className="text-2xl font-bold mb-2 text-gray-800">Review Your Documents & Provide Consent</h2>
        <p className="text-gray-500 mb-6 text-sm">We have extracted the information from your uploaded documents. Please review the details below.</p>

        {/* 1. Personal Identification Document Review */}
        {/* Personal Identification Document Review */}
<div className="mb-6 border rounded-xl p-5 bg-gray-50/50">
  <div className="flex justify-between items-center mb-4">
    <h3 className="font-bold flex items-center text-base text-gray-800">
      <FileText className="mr-2 text-blue-600" size={18}/> Personal Identification Document
    </h3>
    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-medium flex items-center">
      <CheckCircle size={14} className="mr-1"/> Verified
    </span>
  </div>
  <div className="flex gap-6 items-start">
    <div className="flex gap-2">
      {personalDoc.front?.previewUrl ? (
        <img src={personalDoc.front.previewUrl} alt="Front" className="h-24 w-28 object-contain border rounded bg-white p-1" />
      ) : (
        <div className="h-24 w-28 border rounded bg-gray-100 flex items-center text-xs text-gray-400 justify-center">No Image</div>
      )}
      {personalDoc.back?.previewUrl ? (
        <img src={personalDoc.back.previewUrl} alt="Back" className="h-24 w-28 object-contain border rounded bg-white p-1" />
      ) : (
        <div className="h-24 w-28 border rounded bg-gray-100 flex items-center text-xs text-gray-400 justify-center">No Image</div>
      )}
    </div>
    
    {/* Dynamic Grid Mapping for Extracted Data */}
    <div className="flex-1 text-sm grid grid-cols-2 gap-y-2.5">
      <div className="text-gray-500">Document Type</div>
      <div className="font-medium text-right text-gray-800">{personalDoc.documentType || 'Identity Document'}</div>
      
      {/* This automatically loops through whatever fields your backend sends in extracted_data */}
      {Object.keys(personalExtracted).length > 0 ? (
        Object.entries(personalExtracted).map(([key, value]) => (
          <React.Fragment key={key}>
            <div className="text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ')}</div>
            <div className="font-medium text-right text-gray-800 break-all">{String(value)}</div>
          </React.Fragment>
        ))
      ) : (
        <div className="col-span-2 text-xs text-amber-600 italic text-right">
          Waiting for extracted data from backend upload...
        </div>
      )}
    </div>
  </div>
</div>

        {/* 2. Address Proof Document Review */}
        <div className="mb-6 border rounded-xl p-5 bg-gray-50/50">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold flex items-center text-base text-gray-800">
              <HomeIcon className="mr-2 text-blue-600" size={18}/> Address Proof Document
            </h3>
            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-medium flex items-center">
              <CheckCircle size={14} className="mr-1"/> Verified
            </span>
          </div>
          <div className="flex gap-6 items-start">
            <div className="flex gap-2">
              {addressDoc.front?.previewUrl ? (
                <img src={addressDoc.front.previewUrl} alt="Address Proof Front" className="h-24 w-28 object-contain border rounded bg-white p-1" />
              ) : (
                <div className="h-24 w-28 border rounded bg-gray-100 flex items-center text-xs text-gray-400 justify-center">No Front Image</div>
              )}
              {addressDoc.back?.previewUrl ? (
                <img src={addressDoc.back.previewUrl} alt="Address Proof Back" className="h-24 w-28 object-contain border rounded bg-white p-1" />
              ) : (
                <div className="h-24 w-28 border rounded bg-gray-100 flex items-center text-xs text-gray-400 justify-center">No Back Image</div>
              )}
            </div>
            
            {/* Dynamic Extraction Display */}
            <div className="flex-1 text-sm grid grid-cols-2 gap-y-2.5">
              <div className="text-gray-500">Document Type</div>
              <div className="font-medium text-right text-gray-800">{addressDoc.documentType || addressInfo.documentType || 'Address Document'}</div>
              
              {Object.keys(addressExtracted).length > 0 ? (
                Object.entries(addressExtracted).map(([key, value]) => (
                  <React.Fragment key={key}>
                    <div className="text-gray-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                    <div className="font-medium text-right text-gray-800 break-all">{String(value)}</div>
                  </React.Fragment>
                ))
              ) : (
                <div className="col-span-2 text-xs text-gray-400 italic text-right">No additional fields extracted</div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation Footer */}
        <div className="flex justify-between items-center mt-6 pt-4 border-t">
          <button onClick={prevStep} className="px-6 py-2 border rounded-lg hover:bg-gray-50 font-medium text-sm">Back</button>
          <button onClick={nextStep} className="px-8 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold shadow-sm text-sm transition">
            Continue to Biometric Verification →
          </button>
        </div>
      </div>

      {/* Right Sidebar Summaries */}
      <div className="w-80 space-y-6">
        <div className="bg-white p-5 rounded-xl shadow-sm border">
          <h4 className="font-bold mb-4 text-gray-800 text-sm flex items-center"><FileText size={16} className="mr-2 text-blue-600"/> Extraction Summary</h4>
          <ul className="text-xs space-y-3 text-gray-600">
            <li className="flex items-start"><CheckCircle size={15} className="text-green-500 mr-2 shrink-0 mt-0.5"/> 2 Primary documents processed successfully[cite: 1]</li>
            <li className="flex items-start"><CheckCircle size={15} className="text-green-500 mr-2 shrink-0 mt-0.5"/> Backend response data rendered dynamically</li>
            <li className="flex items-start"><CheckCircle size={15} className="text-green-500 mr-2 shrink-0 mt-0.5"/> Rule validation decisions approved</li>
          </ul>
        </div>
        
        <div className="bg-blue-50 p-5 rounded-xl border border-blue-100">
           <h4 className="font-bold mb-3 text-blue-900 text-sm">Terms, Consent and Declarations</h4>
           <div className="space-y-3 text-xs text-blue-900">
             <label className="flex items-start cursor-pointer">
               <input type="checkbox" defaultChecked className="mt-0.5 mr-2 shrink-0" />
               I confirm that the information and documents provided are correct and accurate[cite: 1].
             </label>
             <label className="flex items-start cursor-pointer">
               <input type="checkbox" defaultChecked className="mt-0.5 mr-2 shrink-0" />
               I consent to the verification of my identity and document authenticity.
             </label>
           </div>
        </div>
      </div>
    </div>
  );
}