import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, FileText, Folder, Bell, Headphones, Search, LogOut, ChevronDown } from 'lucide-react';
import { useMsal } from '@azure/msal-react';

export default function CustomerLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { accounts, instance } = useMsal();
  const [showDropdown, setShowDropdown] = useState(false);
  
  // Get dynamic name from MSAL or fall back to stored session state
  const userName = accounts.length > 0 ? accounts[0].name : "Arjun Mehta";
  const userInitials = userName.split(' ').map(n => n[0]).join('').toUpperCase();

  const handleLogout = () => {
    if (instance && accounts.length > 0) {
      instance.logoutPopup();
    }
    localStorage.removeItem('kyc_state');
    navigate('/login');
  };

  const navItems = [
    { name: 'Dashboard', icon: Home, path: '/customer/dashboard' },
    { name: 'KYC / eKYC', icon: FileText, path: '/customer/kyc' },
    { name: 'My Applications', icon: FileText, path: '/customer/applications' },
    { name: 'Documents', icon: Folder, path: '/customer/documents' },
    { name: 'Notifications', icon: Bell, path: '/customer/notifications' },
    { name: 'Support', icon: Headphones, path: '/customer/support' },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r flex flex-col">
        <div className="h-16 flex items-center px-6 bg-slate-900 text-white font-bold text-xl tracking-wide">
          <div className="w-6 h-6 bg-white rounded-full mr-2"></div>
          Company Logo
        </div>
        <nav className="flex-1 py-4">
          {navItems.map((item) => {
            const isActive = location.pathname.includes(item.path);
            return (
              <Link key={item.name} to={item.path} 
                className={`flex items-center px-6 py-3 my-1 font-medium ${isActive ? 'text-blue-600 bg-blue-50 border-r-4 border-blue-600' : 'text-gray-600 hover:bg-gray-50'}`}>
                <item.icon size={20} className="mr-3" />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-slate-900 text-white flex items-center justify-between px-6 relative">
          <h2 className="text-xl font-semibold">Customer Portal</h2>
          <div className="flex items-center gap-6">
            <div className="relative text-gray-800">
              <Search className="absolute left-3 top-2 text-gray-400" size={16} />
              <input type="text" placeholder="Search... (e.g. KYC, Documents, Status)" className="pl-9 pr-4 py-1.5 rounded bg-white w-80 text-sm focus:outline-none" />
            </div>
            <div className="relative">
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">1</span>
            </div>

            {/* User Profile & Hover Dropdown */}
            <div 
              className="relative cursor-pointer flex items-center gap-2 py-2"
              onMouseEnter={() => setShowDropdown(true)}
              onMouseLeave={() => setShowDropdown(false)}
            >
              <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                {userInitials || "AM"}
              </div>
              <span className="text-sm font-medium">{userName}</span>
              <ChevronDown size={16} className="text-slate-400" />

              {showDropdown && (
                <div className="absolute right-0 top-full w-48 bg-white rounded-lg shadow-lg border py-1 z-50 text-gray-800">
                  <div className="px-4 py-2 border-b text-xs text-gray-500">Signed in as <br/><span className="font-semibold text-gray-800">{userName}</span></div>
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center"
                  >
                    <LogOut size={16} className="mr-2" /> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}