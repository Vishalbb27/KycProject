import React, { createContext, useState, useEffect } from 'react';

export const KycContext = createContext();

export const KycProvider = ({ children }) => {
  const [kycData, setKycData] = useState(() => {
    const saved = localStorage.getItem('kyc_state');
    return saved ? JSON.parse(saved) : {
      caseId: null,
      step: 1,
      documents: {
        personalId: { front: null, back: null, status: 'pending' },
        addressProof: { front: null, back: null, status: 'pending' }
      },
      biometric: null,
      extractedInfo: {},
      userName: "" // Starts empty so it reads directly from MSAL login
    };
  });

  useEffect(() => {
    localStorage.setItem('kyc_state', JSON.stringify(kycData));
  }, [kycData]);

  const updateKycData = (newData) => setKycData(prev => ({ ...prev, ...newData }));

  return (
    <KycContext.Provider value={{ kycData, updateKycData }}>
      {children}
    </KycContext.Provider>
  );
};