// src/authConfig.js
import { PublicClientApplication } from '@azure/msal-browser';

export const msalConfig = {
  auth: {
    clientId: "b56dc4ec-ac96-4afc-9869-4b4448777623", // From the Azure Overview page
        
        // If you selected "Any user" in Step 4, use "common". 
        // If you selected "Single tenant", use your specific Directory (tenant) ID.
        authority: "https://login.microsoftonline.com/62c64709-64a9-470a-a7ff-a461d8762e87", 
        
        redirectUri: "http://localhost:5173",
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: false,
  },
};

export const loginRequest = {
  scopes: ["api://b56dc4ec-ac96-4afc-9869-4b4448777623/access_as_user"],
};

// Export the instance so main.jsx can import it
export const msalInstance = new PublicClientApplication(msalConfig);