import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { KycProvider } from './context/KycContext';
import Login from './pages/Login';
import CustomerLayout from './layouts/CustomerLayout';
import InvestigatorLayout from './layouts/InvestigatorLayout';

// Customer Pages
import CustomerDashboard from './pages/DummyPages/Dashboard';
import KycFlow from './pages/CustomerPortal/KycFlow';
import Applications from './pages/CustomerPortal/Applications';
import Documents from './pages/CustomerPortal/Documents';
import Notifications from './pages/CustomerPortal/Steps/Notifications';
import Support from './pages/CustomerPortal/Support';

// Investigator Pages
import InvestigatorDashboard from './pages/InvestigatorPortal/Dashboard';
import InvestigatorCases from './pages/InvestigatorPortal/Cases';
import InvestigatorCaseDetail from './pages/InvestigatorPortal/CaseDetail';
import Reports from './pages/InvestigatorPortal/Reports';
import Configuration from './pages/InvestigatorPortal/Configuration';

function App() {
  return (
    <KycProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<Login />} />
          
          {/* Customer Portal */}
          <Route path="/customer" element={<CustomerLayout />}>
            <Route path="dashboard" element={<CustomerDashboard />} />
            <Route path="kyc" element={<KycFlow />} />
            <Route path="applications" element={<Applications />} />
            <Route path="documents" element={<Documents />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="support" element={<Support />} />
          </Route>

          {/* Investigator Portal */}
          <Route path="/investigator" element={<InvestigatorLayout />}>
            <Route path="dashboard" element={<InvestigatorDashboard />} />
            <Route path="cases" element={<InvestigatorCases />} />
            <Route path="cases/:id" element={<InvestigatorCaseDetail />} />
            <Route path="reports" element={<Reports />} />
            <Route path="configuration" element={<Configuration />} />
          </Route>
        </Routes>
      </Router>
    </KycProvider>
  );
}

export default App;