# app/schemas/kyc_case.py
from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class KycCaseResponse(BaseModel):
    KycCaseId: int
    KycNumber: str
    CustomerId: int
    CurrentState: str
    KycMethod: str
    CreatedAt: datetime
    UpdatedAt: datetime

    class Config:
        from_attributes = True