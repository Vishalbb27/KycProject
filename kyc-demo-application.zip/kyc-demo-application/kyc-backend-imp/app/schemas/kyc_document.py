# app/schemas/kyc_document.py
from typing import Dict, Any, List
from pydantic import BaseModel

class RuleValidationResult(BaseModel):
    decision: str
    rule_results: List[Dict[str, Any]]

class DocumentProcessingResult(BaseModel):
    document_id: int
    version_id: int
    version_number: int
    document_type: str
    status: str
    extracted_data: Dict[str, Any]
    rule_validation: RuleValidationResult