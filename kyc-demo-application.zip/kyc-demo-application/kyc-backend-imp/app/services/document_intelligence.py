import re
from typing import Dict, Any
from azure.ai.formrecognizer.aio import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from app.core.config import settings
from app.core.exceptions import DocumentQualityError

class DocumentIntelligenceService:
    def __init__(self):
        self.client = DocumentAnalysisClient(
            endpoint=settings.AZURE_DOC_INTELLIGENCE_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_DOC_INTELLIGENCE_KEY)
        )

    def _determine_document_type(self, azure_doc_type: str, raw_text: str, doc_number: str | None) -> str:
        """
        Infers the document type using Azure classification, extracted fields,
        and content pattern matching.
        """
        text_upper = raw_text.upper()

        if "PASSPORT" in azure_doc_type.upper() or "PASSPORT" in text_upper:
            return "PASSPORT"

        if "DRIVERLICENSE" in azure_doc_type.upper() or "DRIVING LICENCE" in text_upper or "DRIVING LICENSE" in text_upper:
            return "DRIVING_LICENSE"

        # Check for Aadhaar identifiers
        if "UIDAI" in text_upper or "UNIQUE IDENTIFICATION" in text_upper or "AADHAAR" in text_upper:
            return "AADHAAR"

        # Check for Indian PAN format: 5 letters, 4 digits, 1 letter
        if "INCOME TAX DEPARTMENT" in text_upper or (doc_number and re.match(r"^[A-Z]{5}[0-9]{4}[A-Z]$", doc_number.strip().upper())):
            return "PAN"

        if "NATIONALID" in azure_doc_type.upper():
            return "NATIONAL_ID"

        return "UNKNOWN"

    async def analyze_and_extract(self, front_bytes: bytes, back_bytes: bytes) -> Dict[str, Any]:
        """
        1. Classifies the front document and checks scan quality.
        2. Extracts identity fields via prebuilt-idDocument.
        3. Analyzes the back image to extract missing fields (like Address).
        4. Sanitizes and redacts sensitive identifiers.
        """
        try:
            # Process Front Image
            front_poller = await self.client.begin_analyze_document("prebuilt-idDocument", front_bytes)
            front_result = await front_poller.result()
        except Exception as err:
            raise DocumentQualityError(f"Azure Document Intelligence processing error (Front): {str(err)}")

        if not front_result.documents:
            raise DocumentQualityError("No identifiable identity document found in the front image.")

        front_doc = front_result.documents[0]
        confidence = front_doc.confidence

        if confidence < 0.65:
            raise DocumentQualityError(
                f"Front document quality is too low (Score: {confidence:.2f}). Please upload a clearer copy."
            )

        fields = front_doc.fields
        raw_doc_num = fields.get("DocumentNumber", {}).value if fields.get("DocumentNumber") else None

        raw_full_text = front_result.content or ""
        detected_type = self._determine_document_type(
            azure_doc_type=front_doc.doc_type,
            raw_text=raw_full_text,
            doc_number=str(raw_doc_num) if raw_doc_num else None
        )

        if detected_type == "UNKNOWN":
            raise DocumentQualityError(
                "Document could not be recognized as a supported ID. Please upload a valid ID."
            )

       # 1. Update the initial extraction (Use .content for Address)
        extracted_data = {
            "document_type": detected_type,
            "first_name": fields.get("FirstName").value if fields.get("FirstName") else None,
            "last_name": fields.get("LastName").value if fields.get("LastName") else None,
            "full_name": None,
            "date_of_birth": str(fields.get("DateOfBirth").value) if fields.get("DateOfBirth") else None,
            "document_number": None,
            "address": fields.get("Address").content if fields.get("Address") else None,  # Fix applied here
            "expiry_date": str(fields.get("DateOfExpiration").value) if fields.get("DateOfExpiration") else None,
            "confidence_score": confidence,
            "quality_status": "PASSED"
        }

        # --- PROCESS BACK IMAGE (MANDATORY) ---
        try:
            back_poller = await self.client.begin_analyze_document("prebuilt-idDocument", back_bytes)
            back_result = await back_poller.result()
            
            if back_result.documents:
                back_fields = back_result.documents[0].fields
                
                # Merge Address if the front didn't have one
                if not extracted_data["address"] and back_fields.get("Address"):
                    extracted_data["address"] = back_fields.get("Address").content  # Fix applied here
                    
                # Merge Expiry Date if missing from front
                if not extracted_data["expiry_date"] and back_fields.get("DateOfExpiration"):
                    extracted_data["expiry_date"] = str(back_fields.get("DateOfExpiration").value)
        except Exception as err:
            print(f"Warning: Failed to process back image OCR: {err}")
        # ----------------------------------------

        if extracted_data["first_name"] or extracted_data["last_name"]:
            extracted_data["full_name"] = f"{extracted_data['first_name'] or ''} {extracted_data['last_name'] or ''}".strip()
        elif fields.get("Name"):
            extracted_data["full_name"] = fields.get("Name").value

        if raw_doc_num:
            if detected_type == "AADHAAR":
                extracted_data["document_number"] = "[Aadhaar Redacted]"
            else:
                extracted_data["document_number"] = str(raw_doc_num).strip()

        return extracted_data

    async def close(self):
        await self.client.close()