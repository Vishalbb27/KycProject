import json
from difflib import SequenceMatcher
from typing import List, Dict, Any
from app.models.rules import KycRule

class RuleEngineService:
    @staticmethod
    def _name_similarity(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        return SequenceMatcher(None, a.lower().strip(), b.lower().strip()).ratio()

    @classmethod
    def evaluate(cls, rules: List[KycRule], customer_record: Any, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        results = []
        is_blocked = False

        for rule in rules:
            rule_def = json.loads(rule.RuleDefinition) if isinstance(rule.RuleDefinition, str) else rule.RuleDefinition
            passed = True
            reason = None

            if rule.RuleType == "DOCUMENT_VALIDATION":
                # Check minimum confidence & required fields
                if extracted_data.get("confidence_score", 0) < 0.70:
                    passed = False
                    reason = "Document confidence score below quality threshold"

            elif rule.RuleType == "NAME_MATCH":
                threshold = rule_def.get("threshold", 0.80)
                full_name_extracted = extracted_data.get("full_name") or ""
                cust_full_name = f"{customer_record.FirstName} {customer_record.LastName}".strip()
                score = cls._name_similarity(cust_full_name, full_name_extracted)
                if score < threshold:
                    passed = False
                    reason = f"Name match score ({score:.2f}) below threshold ({threshold})"

            elif rule.RuleType == "FIELD_MATCH" and rule.RuleCode == "RULE-DOB-001":
                extracted_dob = extracted_data.get("date_of_birth")
                cust_dob = str(customer_record.DateOfBirth) if customer_record.DateOfBirth else None
                if extracted_dob and cust_dob and extracted_dob != cust_dob:
                    passed = False
                    reason = "Date of birth does not match customer profile"

            if not passed and rule.Severity == "BLOCKING":
                is_blocked = True

            results.append({
                "rule_code": rule.RuleCode,
                "rule_name": rule.RuleName,
                "severity": rule.Severity,
                "passed": passed,
                "reason": reason
            })

        return {
            "decision": "REJECTED" if is_blocked else "APPROVED",
            "rule_results": results
        }