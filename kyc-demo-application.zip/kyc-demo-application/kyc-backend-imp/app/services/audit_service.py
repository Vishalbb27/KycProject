# app/services/audit_service.py
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.audit import KycAuditEvent

class AuditService:
    @staticmethod
    async def log_event(
        db: AsyncSession, case_id: int, event_type: str, entity_type: str, 
        entity_id: str, action: str, actor_id: str, prev_state: str = None, 
        new_state: str = None, reason: str = None
    ):
        audit_entry = KycAuditEvent(
            KycCaseId=case_id,
            EventType=event_type,
            EntityType=entity_type,
            EntityId=entity_id,
            Action=action,
            PreviousState=prev_state,
            NewState=new_state,
            ActorId=actor_id,
            Reason=reason
        )
        db.add(audit_entry)
        # Flush is recommended here if the caller isn't immediately committing
        await db.flush()