# app/api/deps.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.core.security import verify_entra_token
from app.models.customer import Customer

security = HTTPBearer()

async def get_current_user_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    return await verify_entra_token(credentials.credentials)

async def get_current_customer(
    token_payload: dict = Depends(get_current_user_token),
    db: AsyncSession = Depends(get_db)
) -> Customer:
    """
    Extracts the user's email/OID from the Entra ID MSAL token and matches it to a Customer record.
    """
    email = token_payload.get("preferred_username") or token_payload.get("email")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: Email missing")
    
    stmt = select(Customer).where(Customer.Email == email, Customer.CustomerStatus == "ACTIVE")
    result = await db.execute(stmt)
    customer = result.scalars().first()
    
    if not customer:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Customer profile not found")
        
    return customer