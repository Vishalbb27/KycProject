import uuid
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.api.deps import get_current_customer
from app.models.customer import Customer, KycCustomerSnapshot
from app.models.kyc_case import KycCase
from app.schemas.kyc_case import KycCaseResponse
from app.schemas.common import ApiResponse
from app.services.audit_service import AuditService

router = APIRouter()

@router.post("/init", response_model=ApiResponse[KycCaseResponse], status_code=status.HTTP_200_OK)
async def initialize_kyc_case(
    customer: Customer = Depends(get_current_customer),
    db: AsyncSession = Depends(get_db)
):
    """
    Called upon MSAL login: Creates a new KYC case or fetches the existing active case.
    """
    # Check for active non-completed case
    stmt = select(KycCase).where(
        KycCase.CustomerId == customer.CustomerId,
        KycCase.CurrentState.in_(["DRAFT", "DOCUMENTS_READY", "PROCESSING"])
    ).order_by(KycCase.CreatedAt.desc())
    
    result = await db.execute(stmt)
    existing_case = result.scalars().first()

    if existing_case:
        return ApiResponse(
            success=True,
            message="Active KYC case retrieved",
            data=KycCaseResponse.from_orm(existing_case)
        )

    # Create new KYC Case
    kyc_number = f"KYC-2026-{str(uuid.uuid4().int)[:6]}"
    new_case = KycCase(
        KycNumber=kyc_number,
        CustomerId=customer.CustomerId,
        CurrentState="DRAFT",
        KycMethod="MANUAL",
        CreatedBy="CUSTOMER"
    )
    db.add(new_case)
    await db.flush()

    # Create baseline snapshot from Customer record
    snapshot = KycCustomerSnapshot(
        KycCaseId=new_case.KycCaseId,
        CustomerName=f"{customer.FirstName} {customer.LastName}".strip(),
        DateOfBirth=customer.DateOfBirth,
        PhoneNumber=customer.PhoneNumber,
        Email=customer.Email,
        Address=f"{customer.AddressLine1 or ''}, {customer.City or ''}, {customer.State or ''}".strip(),
        IdentityReference="CUSTOMER-INIT"
    )
    db.add(snapshot)

    await AuditService.log_event(
        db=db,
        case_id=new_case.KycCaseId,
        event_type="KYC_CREATED",
        entity_type="KYC_CASE",
        entity_id=new_case.KycNumber,
        action="CREATE",
        actor_id=customer.CustomerNumber,
        prev_state=None,
        new_state="DRAFT",
        reason="KYC initiated after authentication"
    )

    await db.commit()
    await db.refresh(new_case)

    return ApiResponse(
        success=True,
        message="New KYC case initiated successfully",
        data=KycCaseResponse.from_orm(new_case)
    )