from datetime import datetime
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.api.deps import get_current_customer
from app.models.customer import Customer
from app.models.kyc_case import KycCase
from app.models.kyc_document import KycDocument, KycDocumentVersion
from app.models.rules import KycRule
from app.schemas.kyc_document import DocumentProcessingResult
from app.schemas.common import ApiResponse
from app.services.azure_blob import AzureBlobService
from app.services.document_intelligence import DocumentIntelligenceService
from app.services.rule_engine import RuleEngineService
from app.services.audit_service import AuditService
from app.core.exceptions import DocumentQualityError

router = APIRouter()

ALLOWED_DOC_TYPES = {"AADHAAR", "PAN", "PASSPORT", "VOTER_ID", "BIRTH_CERTIFICATE", "DRIVING_LICENSE", "NATIONAL_ID"}

@router.post("/upload", response_model=ApiResponse[DocumentProcessingResult])
async def upload_kyc_document(
    case_id: int = Form(...),
    document_id: int = Form(None), 
    front_image: UploadFile = File(...),
    back_image: UploadFile = File(...),  # Now strictly required
    customer: Customer = Depends(get_current_customer),
    db: AsyncSession = Depends(get_db)
):
    # 1. Enforce PNG-only upload for BOTH files
    if front_image.content_type != "image/png" or back_image.content_type != "image/png":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Both front and back images must be in PNG format. Please convert your files to .png"
        )

    # 2. Verify Case Ownership
    case = await db.get(KycCase, case_id)
    if not case or case.CustomerId != customer.CustomerId:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="KYC case not found")

    front_bytes = await front_image.read()
    back_bytes = await back_image.read()

    # 3. Azure Document Intelligence Auto-Classification & Extraction
    doc_intelligence = DocumentIntelligenceService()
    try:
        # Pass both front and back bytes to the AI
        extracted_data = await doc_intelligence.analyze_and_extract(front_bytes, back_bytes)
    except DocumentQualityError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    finally:
        await doc_intelligence.close()

    doc_type_upper = extracted_data.get("document_type", "UNKNOWN")
    if doc_type_upper not in ALLOWED_DOC_TYPES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Uploaded document was classified as {doc_type_upper}. Allowed types: {list(ALLOWED_DOC_TYPES)}"
        )

    # 4. Fetch Active Rules and Run Validation Engine
    rules_stmt = select(KycRule).where(KycRule.IsActive == True)
    rules_res = await db.execute(rules_stmt)
    rules = rules_res.scalars().all()
    rule_assessment = RuleEngineService.evaluate(rules, customer, extracted_data)

    # 5. Azure Blob Storage Setup
    blob_service = AzureBlobService()
    doc_hash = blob_service.calculate_hash(front_bytes)

    # 6. Database Transaction: Handle New Document or Edit/Version Increment
    if document_id:
        # Edit path: Verify existence and increment version
        kyc_doc = await db.get(KycDocument, document_id)
        if not kyc_doc or kyc_doc.KycCaseId != case_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document to edit not found")
        
        current_version = await db.get(KycDocumentVersion, kyc_doc.CurrentVersionId)
        next_version_num = (current_version.VersionNumber + 1) if current_version else 1
        prev_version_id = current_version.KycDocumentVersionId if current_version else None
        action_name = "UPDATE_VERSION"
    else:
        # Initial upload path
        doc_count_stmt = select(KycDocument).where(KycDocument.KycCaseId == case_id)
        res = await db.execute(doc_count_stmt)
        count = len(res.scalars().all()) + 1
        generated_doc_num = f"DOC-{str(case_id).zfill(6)}-{str(count).zfill(2)}"

        kyc_doc = KycDocument(
            KycCaseId=case_id,
            DocumentNumber=generated_doc_num,
            DocumentType=doc_type_upper,
            DocumentSource="MANUAL",
            CurrentStatus="PENDING"
        )
        db.add(kyc_doc)
        await db.flush()
        next_version_num = 1
        prev_version_id = None
        action_name = "CREATE_DOCUMENT"

    # Define Blob Paths (Using .png extension)
    front_path = f"{case_id}/{kyc_doc.DocumentNumber}/v{next_version_num}_front.png"
    back_path = f"{case_id}/{kyc_doc.DocumentNumber}/v{next_version_num}_back.png"

    # 7. Upload Both PNGs to Blob Storage
    try:
        await blob_service.upload_document_image(front_bytes, front_path)
        await blob_service.upload_document_image(back_bytes, back_path)
    finally:
        await blob_service.close()

    # 8. Record Version Entry
    doc_version = KycDocumentVersion(
        KycDocumentId=kyc_doc.KycDocumentId,
        VersionNumber=next_version_num,
        PreviousVersionId=prev_version_id,
        ProcessingStatus="COMPLETED",
        DecisionStatus=rule_assessment["decision"],
        DocumentHash=doc_hash,
        BlobContainer=blob_service.container_name,
        FrontBlobPath=front_path,
        BackBlobPath=back_path,
        ProcessedAt=datetime.utcnow()
    )
    db.add(doc_version)
    await db.flush()

    # 9. Update Parent Document Pointers
    kyc_doc.CurrentVersionId = doc_version.KycDocumentVersionId
    kyc_doc.CurrentStatus = "VERIFIED" if rule_assessment["decision"] == "APPROVED" else "REJECTED"
    kyc_doc.UpdatedAt = datetime.utcnow()

    # 10. Update Case State to DOCUMENTS_READY
    case.CurrentState = "DOCUMENTS_READY"
    case.UpdatedAt = datetime.utcnow()

    # 11. Audit Trail Entry
    await AuditService.log_event(
        db=db,
        case_id=case_id,
        event_type="DOCUMENT_PROCESSED",
        entity_type="KYC_DOCUMENT_VERSION",
        entity_id=str(doc_version.KycDocumentVersionId),
        action=action_name,
        actor_id=customer.CustomerNumber,
        prev_state="PROCESSING",
        new_state=kyc_doc.CurrentStatus,
        reason=f"Uploaded and processed via Azure Document Intelligence (Version {next_version_num})"
    )

    await db.commit()

    return ApiResponse(
        success=True,
        message="Document uploaded, verified and extracted successfully.",
        data=DocumentProcessingResult(
            document_id=kyc_doc.KycDocumentId,
            version_id=doc_version.KycDocumentVersionId,
            version_number=next_version_num,
            document_type=kyc_doc.DocumentType,
            status=kyc_doc.CurrentStatus,
            extracted_data=extracted_data,
            rule_validation=rule_assessment
        )
    )