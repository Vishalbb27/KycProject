# app/api/v1/router.py
from fastapi import APIRouter
from app.api.v1.endpoints import cases, documents

api_router = APIRouter()
api_router.include_router(cases.router, prefix="/cases", tags=["Cases"])
api_router.include_router(documents.router, prefix="/documents", tags=["Documents"])