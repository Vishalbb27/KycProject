# app/models/kyc_case.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class KycCase(Base):
    __tablename__ = "KycCase"

    KycCaseId = Column(Integer, primary_key=True, index=True, autoincrement=True)
    KycNumber = Column(String(50), unique=True, nullable=False)
    CustomerId = Column(Integer, ForeignKey("Customer.CustomerId"), nullable=False)
    CurrentState = Column(String(50), default="DRAFT") # DRAFT, DOCUMENTS_READY, PROCESSING, APPROVED, REJECTED
    KycMethod = Column(String(50), default="MANUAL")
    CreatedAt = Column(DateTime, default=datetime.utcnow)
    SubmittedAt = Column(DateTime, nullable=True)
    CompletedAt = Column(DateTime, nullable=True)
    CreatedBy = Column(String(50), default="CUSTOMER")
    UpdatedAt = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    documents = relationship("KycDocument", back_populates="case")
    customer = relationship("Customer", back_populates="kyc_cases")