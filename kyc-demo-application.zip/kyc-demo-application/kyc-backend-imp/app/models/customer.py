# app/models/customer.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, Date, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base

class Customer(Base):
    __tablename__ = "Customer"

    CustomerId = Column(Integer, primary_key=True, index=True, autoincrement=True)
    CustomerNumber = Column(String(50), unique=True, nullable=False)
    FirstName = Column(String(100), nullable=False)
    LastName = Column(String(100), nullable=False)
    DateOfBirth = Column(Date, nullable=False)
    PhoneNumber = Column(String(20), nullable=False)
    Email = Column(String(150), nullable=False)
    CustomerStatus = Column(String(50), default="ACTIVE")
    AddressType = Column(String(50), nullable=True)
    AddressLine1 = Column(String(255), nullable=True)
    AddressLine2 = Column(String(255), nullable=True)
    City = Column(String(100), nullable=True)
    State = Column(String(100), nullable=True)
    PostalCode = Column(String(20), nullable=True)
    Country = Column(String(50), nullable=True)

    kyc_cases = relationship("KycCase", back_populates="customer")

class KycCustomerSnapshot(Base):
    __tablename__ = "KycCustomerSnapshot"

    KycCustomerSnapshotId = Column(Integer, primary_key=True, autoincrement=True)
    KycCaseId = Column(Integer, ForeignKey("KycCase.KycCaseId"), nullable=False)
    CustomerName = Column(String(200), nullable=False)
    DateOfBirth = Column(Date, nullable=True)
    PhoneNumber = Column(String(20), nullable=True)
    Email = Column(String(150), nullable=True)
    Address = Column(String(500), nullable=True)
    IdentityReference = Column(String(100), nullable=True)
    SnapshotCreatedAt = Column(DateTime, default=datetime.utcnow)