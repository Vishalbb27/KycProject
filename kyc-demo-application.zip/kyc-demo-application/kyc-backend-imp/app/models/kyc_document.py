# app/models/kyc_document.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.db.base import Base

class KycDocument(Base):
    __tablename__ = "KycDocument"

    KycDocumentId = Column(Integer, primary_key=True, index=True, autoincrement=True)
    KycCaseId = Column(Integer, ForeignKey("KycCase.KycCaseId"), nullable=False)
    DocumentNumber = Column(String(100), nullable=True)  # System tracking ID e.g. DOC-000123-01
    DocumentType = Column(String(50), nullable=False)    # PAN, AADHAAR, PASSPORT, VOTER_ID, BIRTH_CERTIFICATE
    DocumentSource = Column(String(50), default="MANUAL")
    CurrentVersionId = Column(Integer, nullable=True)
    CurrentStatus = Column(String(50), default="PENDING") # PENDING, VERIFIED, REJECTED
    CreatedAt = Column(DateTime, default=datetime.utcnow)
    UpdatedAt = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    case = relationship("KycCase", back_populates="documents")
    versions = relationship("KycDocumentVersion", back_populates="document", cascade="all, delete-orphan")


class KycDocumentVersion(Base):
    __tablename__ = "KycDocumentVersion"

    KycDocumentVersionId = Column(Integer, primary_key=True, index=True, autoincrement=True)
    KycDocumentId = Column(Integer, ForeignKey("KycDocument.KycDocumentId"), nullable=False)
    VersionNumber = Column(Integer, nullable=False, default=1)
    PreviousVersionId = Column(Integer, ForeignKey("KycDocumentVersion.KycDocumentVersionId"), nullable=True)
    ProcessingStatus = Column(String(50), default="PROCESSING") # PROCESSING, COMPLETED, FAILED
    DecisionStatus = Column(String(50), default="PENDING")      # PENDING, APPROVED, REJECTED
    DocumentHash = Column(String(128), nullable=False)
    BlobContainer = Column(String(100), default="kyc-documents")
    FrontBlobPath = Column(String(500), nullable=False)
    BackBlobPath = Column(String(500), nullable=True)
    ProcessedAt = Column(DateTime, nullable=True)
    RejectedReason = Column(String(200), nullable=True)
    RejectedNotes = Column(Text, nullable=True)
    CreatedAt = Column(DateTime, default=datetime.utcnow)

    document = relationship("KycDocument", back_populates="versions")