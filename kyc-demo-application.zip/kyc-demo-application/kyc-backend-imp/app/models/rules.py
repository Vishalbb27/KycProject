# app/models/rules.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text
from app.db.base import Base

class KycRule(Base):
    __tablename__ = "KycRule"

    KycRuleId = Column(Integer, primary_key=True, index=True)
    RuleCode = Column(String(50), unique=True, nullable=False)
    RuleName = Column(String(200), nullable=False)
    RuleType = Column(String(50), nullable=False)       # IDENTITY_MATCH, FIELD_MATCH, NAME_MATCH, DOCUMENT_VALIDATION
    PolicyCode = Column(String(50), default="INDIA-KYC")
    PolicyVersion = Column(String(20), default="1.0")
    RuleDefinition = Column(Text, nullable=False)        # JSON configuration string
    Severity = Column(String(20), default="BLOCKING")    # BLOCKING, WARNING
    ActiveFrom = Column(DateTime, default=datetime.utcnow)
    ActiveTo = Column(DateTime, nullable=True)
    IsActive = Column(Boolean, default=True)
    CreatedAt = Column(DateTime, default=datetime.utcnow)