# app/models/audit.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text
from app.db.base import Base

class KycAuditEvent(Base):
    __tablename__ = "KycAuditEvent"

    KycAuditEventId = Column(Integer, primary_key=True, autoincrement=True)
    KycCaseId = Column(Integer, nullable=False)
    EventType = Column(String(100), nullable=False)
    EntityType = Column(String(50), nullable=False)
    EntityId = Column(String(100), nullable=True)
    Action = Column(String(50), nullable=False)
    PreviousState = Column(String(50), nullable=True)
    NewState = Column(String(50), nullable=True)
    ActorType = Column(String(50), default="CUSTOMER")
    ActorId = Column(String(100), nullable=False)
    Reason = Column(String(255), nullable=True)
    CorrelationId = Column(String(100), nullable=True)
    EventData = Column(Text, nullable=True)
    CreatedAt = Column(DateTime, default=datetime.utcnow)