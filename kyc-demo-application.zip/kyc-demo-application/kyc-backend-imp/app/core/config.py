# app/core/config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "KYC Backend"
    ENVIRONMENT: str = "development"
    
    # Azure Entra ID Auth
    AZURE_TENANT_ID: str
    AZURE_CLIENT_ID: str
    
    # Database
    DATABASE_URL: str
    
    # Azure Storage
    AZURE_STORAGE_CONNECTION_STRING: str
    AZURE_BLOB_CONTAINER: str = "kyc-documents"
    
    # Azure Document Intelligence
    AZURE_DOC_INTELLIGENCE_ENDPOINT: str
    AZURE_DOC_INTELLIGENCE_KEY: str

    class Config:
        env_file = ".env"

settings = Settings()