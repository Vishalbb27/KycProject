# app/core/exceptions.py
class BaseAppException(Exception):
    def __init__(self, status_code: int, error_code: str, detail: str):
        self.status_code = status_code
        self.error_code = error_code
        self.detail = detail

class DocumentQualityError(BaseAppException):
    def __init__(self, detail: str):
        super().__init__(status_code=422, error_code="DOCUMENT_QUALITY_FAILURE", detail=detail)