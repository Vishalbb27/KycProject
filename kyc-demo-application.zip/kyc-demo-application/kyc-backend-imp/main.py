import logging
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.router import api_router
from app.core.exceptions import DocumentQualityError, BaseAppException

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("kyc_backend")

app = FastAPI(
    title="KYC Onboarding & Verification API",
    description="Production-grade Azure & FastAPI backend for identity verification.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware

# app = FastAPI()

# MUST be right after app = FastAPI()
# MUST be right after app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173/"], # ONLY explicit URLs are allowed when credentials=True
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ... your routers down here

@app.exception_handler(DocumentQualityError)
async def document_quality_handler(request: Request, exc: DocumentQualityError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"success": False, "error": {"code": "DOCUMENT_QUALITY_FAILURE", "message": exc.detail}}
    )

@app.exception_handler(BaseAppException)
async def custom_app_exception_handler(request: Request, exc: BaseAppException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": {"code": exc.error_code, "message": exc.detail}}
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled Internal Server Error", exc_info=exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "error": {"code": "INTERNAL_SERVER_ERROR", "message": "An unexpected error occurred. Please try again."}}
    )

# ... existing app = FastAPI(...) setup ...
# ... exception handlers ...

# --- LOCAL AUTH BYPASS FOR TESTING ---
# --- LOCAL AUTH BYPASS FOR TESTING ---
# from app.api.deps import get_current_customer
# from app.db.session import get_db
# from app.models.customer import Customer
# from fastapi import Depends
# from sqlalchemy import select
# from sqlalchemy.ext.asyncio import AsyncSession

# async def mock_get_current_customer(db: AsyncSession = Depends(get_db)):
#     # Bypasses all tokens and just fetches Vishal directly from your Azure SQL DB
#     result = await db.execute(
#         select(Customer).where(Customer.Email == 'vishal.test@example.com')
#     )
#     return result.scalars().first()

# app.dependency_overrides[get_current_customer] = mock_get_current_customer
# -------------------------------------
# -------------------------------------

from fastapi import FastAPI
# Make sure you import your routers!
from app.api.v1.endpoints import cases, documents 

app = FastAPI()

# Include the routers with their specific prefixes
app.include_router(cases.router, prefix="/api/v1/cases", tags=["Cases"])
app.include_router(documents.router, prefix="/api/v1/documents", tags=["Documents"])