import React, { createContext, useContext, useState, useEffect } from 'react';
import localforage from 'localforage';

const KycContext = createContext(null);

// Configure localforage to use IndexedDB
localforage.config({
  name: 'EnterpriseKYC',
  storeName: 'kyc_data'
});

const defaultState = {
  currentStep: 1,
  method: 'MANUAL',
  frontImage: null,
  backImage: null,
  extractedData: null,
  ruleValidation: null,
  otpVerified: false,
  selfieImage: null,
  livenessScore: 96.4,
  faceMatchScore: 98.6,
  submitted: false
};

export const KycProvider = ({ children }) => {
  const [kycState, setKycState] = useState(defaultState);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load state asynchronously from IndexedDB on mount
  useEffect(() => {
    localforage.getItem('kyc_workflow_state').then((cached) => {
      if (cached) {
        setKycState(cached);
      }
      setIsLoaded(true);
    }).catch((err) => {
      console.error("Error loading KYC state from IndexedDB:", err);
      setIsLoaded(true);
    });
  }, []);

  // Save state to IndexedDB whenever it changes
  useEffect(() => {
    if (isLoaded) {
      localforage.setItem('kyc_workflow_state', kycState).catch((err) => {
        console.error("Error saving to IndexedDB:", err);
      });
    }
  }, [kycState, isLoaded]);

  const updateKyc = (fields) => {
    setKycState((prev) => ({ ...prev, ...fields }));
  };

  const resetKyc = () => {
    localforage.removeItem('kyc_workflow_state');
    setKycState(defaultState);
  };

  // Prevent rendering children until the heavy image data is pulled from the database
  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-gray-500 text-sm">
        Loading session...
      </div>
    );
  }

  return (
    <KycContext.Provider value={{ kycState, updateKyc, resetKyc }}>
      {children}
    </KycContext.Provider>
  );
};

export const useKyc = () => useContext(KycContext);