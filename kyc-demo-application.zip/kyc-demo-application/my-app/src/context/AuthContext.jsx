import React, { createContext, useContext, useState, useEffect } from 'react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig, loginRequest } from '../config/msalConfig';
import { kycApi } from '../services/kycService';
import localforage from 'localforage';

export const msalInstance = new PublicClientApplication(msalConfig);
const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const cached = localStorage.getItem('auth_user');
    return cached ? JSON.parse(cached) : null;
  });
  const [caseData, setCaseData] = useState(() => {
    const cached = localStorage.getItem('active_kyc_case');
    return cached ? JSON.parse(cached) : null;
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    msalInstance.initialize().catch(console.error);
  }, []);

  const initKycCase = async (customerProfile) => {
    try {
      const response = await kycApi.initCase({ customerId: customerProfile.id });
      setCaseData(response.data);
      localStorage.setItem('active_kyc_case', JSON.stringify(response.data));
    } catch (err) {
      console.warn("Using fallback KYC Case generation", err);
      const fallback = {
        KycCaseId: 1024,
        KycNumber: "KYC-2026-000123",
        CustomerId: 501,
        CurrentState: "INITIATED",
        KycMethod: "MANUAL",
        CreatedAt: new Date().toISOString(),
        UpdatedAt: new Date().toISOString()
      };
      setCaseData(fallback);
      localStorage.setItem('active_kyc_case', JSON.stringify(fallback));
    }
  };

  const loginWithMSAL = async () => {
    setLoading(true);
    try {
      const response = await msalInstance.loginPopup(loginRequest);
      const profile = {
        name: response.account.name || "Arjun Mehta",
        email: response.account.username,
        role: "CUSTOMER",
        id: response.account.homeAccountId
      };
      setUser(profile);
      localStorage.setItem('auth_user', JSON.stringify(profile));
      await initKycCase(profile);
    } catch (error) {
      console.error("MSAL Login Failed:", error);
    } finally {
      setLoading(false);
    }
  };

  const loginDummy = async (role = "CUSTOMER") => {
    setLoading(true);
    const profile = role === "INVESTIGATOR" 
      ? { name: "Agent Sarah Connor", email: "investigator@company.com", role: "INVESTIGATOR", id: 99 }
      : { name: "Arjun Mehta", email: "arjun.mehta@example.com", role: "CUSTOMER", id: 101 };
    
    setUser(profile);
    localStorage.setItem('auth_user', JSON.stringify(profile));
    
    if (role === "CUSTOMER") {
      await initKycCase(profile);
    }
    setLoading(false);
  };

  const logout = async () => {
    setUser(null);
    setCaseData(null);
    localStorage.removeItem('auth_user');
    localStorage.removeItem('active_kyc_case');
    localStorage.clear();
    try {
      await localforage.removeItem('kyc_workflow_state');
    } catch (err) {
      console.error("Failed to clear localforage on logout", err);
    }
  };

  return (
    <AuthContext.Provider value={{ user, caseData, loginWithMSAL, loginDummy, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Only ONE of this export at the very bottom
export const useAuth = () => useContext(AuthContext);