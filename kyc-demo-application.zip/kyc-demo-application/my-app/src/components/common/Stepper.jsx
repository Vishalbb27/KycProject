import React from 'react';
import { Check } from 'lucide-react';

export const Stepper = ({ currentStep }) => {
  const steps = [
    { number: 1, label: "Choose Method" },
    { number: 2, label: "Upload Document & Consent" },
    { number: 3, label: "Biometric Verification" },
    { number: 4, label: "Processing" },
  ];

  return (
    <div className="w-full py-4 mb-6">
      <div className="flex items-center justify-between max-w-4xl mx-auto relative">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gray-200 -translate-y-1/2 z-0" />
        {steps.map((s) => {
          const isDone = currentStep > s.number;
          const isCurrent = currentStep === s.number;

          return (
            <div key={s.number} className="relative z-10 flex flex-col items-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center font-medium text-sm transition-colors ${
                  isDone
                    ? 'bg-emerald-600 text-white'
                    : isCurrent
                    ? 'bg-blue-600 text-white ring-4 ring-blue-100'
                    : 'bg-white text-gray-500 border-2 border-gray-300'
                }`}
              >
                {isDone ? <Check className="w-4 h-4" /> : s.number}
              </div>
              <span
                className={`text-xs mt-2 font-medium ${
                  isCurrent ? 'text-blue-600' : isDone ? 'text-gray-800' : 'text-gray-400'
                }`}
              >
                {s.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};