import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, FileCheck2, FolderKanban, FileText, Bell, HelpCircle } from 'lucide-react';

export const Sidebar = () => {
  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'KYC / eKYC', icon: FileCheck2, path: '/kyc' },
    { name: 'My Applications', icon: FolderKanban, path: '/applications' },
    { name: 'Documents', icon: FileText, path: '/documents' },
    { name: 'Notifications', icon: Bell, path: '/notifications' },
    { name: 'Support', icon: HelpCircle, path: '/support' },
  ];

  return (
    <aside className="w-60 bg-white border-r border-gray-200 min-h-[calc(100vh-4rem)] p-4 flex flex-col justify-between">
      <nav className="space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`
            }
          >
            <item.icon className="w-4 h-4" />
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};