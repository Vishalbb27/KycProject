import React from 'react';
import { Search, Bell, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Header = () => {
  const { user, logout } = useAuth();

  return (
    <header className="h-16 bg-white border-b border-gray-200 px-6 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <span className="font-semibold text-gray-800 text-lg">Company Logo</span>
        </div>
        <span className="text-gray-400">|</span>
        <h1 className="text-gray-700 font-medium">Customer Portal</h1>
      </div>

      <div className="flex items-center space-x-5">
        <div className="relative w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search... (e.g. KYC, Documents, Status)"
            className="w-full pl-9 pr-4 py-1.5 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="relative">
          <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white rounded-full text-xs flex items-center justify-center font-bold">
              1
            </span>
          </button>
        </div>

        <div className="flex items-center space-x-3 border-l pl-4 border-gray-200">
          <div className="w-9 h-9 rounded-full bg-blue-700 text-white flex items-center justify-center text-sm font-semibold">
            AS
          </div>
          <div className="text-left hidden md:block">
            <p className="text-sm font-medium text-gray-800 leading-tight">{user?.name || "Arjun Mehta"}</p>
            <button onClick={logout} className="text-xs text-red-500 hover:underline">Logout</button>
          </div>
        </div>
      </div>
    </header>
  );
};