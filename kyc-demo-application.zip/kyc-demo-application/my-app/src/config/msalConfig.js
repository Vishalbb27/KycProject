import { LogLevel } from "@azure/msal-browser";

export const msalConfig = {
  auth: {
    clientId: "<CLIENT_ID>", // Replace with Azure AD App Client ID
    authority: "https://login.microsoftonline.com/<TENANT_ID>",
    redirectUri: "http://localhost:5173",
    // postLogoutRedirectUri: window.location.origin
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (!containsPii && level === LogLevel.Error) {
          console.error(message);
        }
      },
    },
  },
};

export const loginRequest = {
    scopes: ["api://<CLIENT_ID>/access_as_user"],
  };