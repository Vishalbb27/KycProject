import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, ArrowRight, FileText, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useKyc } from '../context/KycContext';

export const Dashboard = () => {
  const { user, caseData } = useAuth();
  const { kycState } = useKyc();
  const navigate = useNavigate();

  const isKycSubmitted = kycState.submitted;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between shadow-sm">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}</h1>
          <p className="text-sm text-gray-500">Manage your applications, documents, and profile from your dashboard.</p>
        </div>
        <div className="mt-4 md:mt-0 px-4 py-2 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium">
          Customer ID: #{user?.id || '101'}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* KYC Status Card */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col">
          <div className="flex items-center space-x-3 mb-4">
            {isKycSubmitted ? (
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                <CheckCircle className="w-5 h-5" />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
                <ShieldAlert className="w-5 h-5" />
              </div>
            )}
            <div>
              <h3 className="font-bold text-gray-900">Identity Verification (KYC)</h3>
              <p className="text-xs text-gray-500">
                {isKycSubmitted ? "Verification processing" : "Action required to unlock services"}
              </p>
            </div>
          </div>
          
          <div className="flex-1 text-sm text-gray-600 mb-6">
            {isKycSubmitted ? (
              "Your KYC documents have been submitted and are currently under review. We will notify you once the process is complete."
            ) : (
              "Regulations require us to verify your identity. Please complete your KYC to gain full access to all platform features."
            )}
          </div>
          
          <button
            onClick={() => navigate('/kyc')}
            className={`w-full py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
              isKycSubmitted 
                ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <span>{isKycSubmitted ? "View Status" : "Complete KYC Now"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Active Applications Card */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Recent Applications</h3>
              <p className="text-xs text-gray-500">Track your ongoing requests</p>
            </div>
          </div>
          
          {caseData ? (
            <div className="flex-1 space-y-3 mt-2">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-100">
                <div>
                  <p className="text-sm font-semibold text-gray-800">{caseData.KycNumber}</p>
                  <p className="text-xs text-gray-500">KYC Onboarding</p>
                </div>
                <span className="px-2.5 py-1 bg-blue-100 text-blue-700 text-[11px] font-bold rounded">
                  {isKycSubmitted ? "PROCESSING" : caseData.CurrentState}
                </span>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-sm text-gray-400">
              No active applications found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};