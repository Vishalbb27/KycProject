import React from 'react';
import { ShieldCheck, UserCheck, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export const Login = () => {
  const { loginWithMSAL, loginDummy, loading } = useAuth();
  const navigate = useNavigate();

  const handleCustomerLogin = async (useMsal = false) => {
    if (useMsal) {
      await loginWithMSAL();
    } else {
      await loginDummy("CUSTOMER");
    }
    
    navigate('/kyc');
  };

  const handleInvestigatorLogin = async () => {
    await loginDummy("INVESTIGATOR");
    navigate('/investigator');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white border border-gray-200 rounded-2xl p-8 shadow-sm space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white mx-auto">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Identity & KYC Portal</h2>
          <p className="text-xs text-gray-500">Sign in to start your identity verification or review applications</p>
        </div>

        <div className="space-y-3 pt-2">
          {/* MSAL Production Login */}
          <button
            onClick={() => handleCustomerLogin(true)}
            disabled={loading}
            className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold flex items-center justify-center space-x-2 shadow-sm transition"
          >
            <Shield className="w-4 h-4" />
            <span>Sign In with Microsoft (MSAL)</span>
          </button>

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-gray-200"></div>
            <span className="flex-shrink mx-3 text-xs text-gray-400">or use test sandbox</span>
            <div className="flex-grow border-t border-gray-200"></div>
          </div>

          {/* Dummy Customer Login */}
          <button
            onClick={() => handleCustomerLogin(false)}
            disabled={loading}
            className="w-full py-2.5 px-4 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg text-sm font-medium flex items-center justify-center space-x-2 transition"
          >
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Dummy Customer Login (Arjun Mehta)</span>
          </button>

          {/* Dummy Investigator Login */}
          <button
            onClick={handleInvestigatorLogin}
            disabled={loading}
            className="w-full py-2.5 px-4 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 rounded-lg text-sm font-medium flex items-center justify-center space-x-2 transition"
          >
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            <span>Dummy Investigator Login</span>
          </button>
        </div>
      </div>
    </div>
  );
};