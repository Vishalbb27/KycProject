import React, { useState, useEffect } from 'react';
import { ShieldCheck, Search, Filter, Eye, CheckCircle, XCircle } from 'lucide-react';
import { kycApi } from '../../services/kycService';

export const InvestigatorDashboard = () => {
  const [cases, setCases] = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);

  useEffect(() => {
    kycApi.getInvestigatorCases().then(setCases);
  }, []);

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Investigator Review Portal</h2>
          <p className="text-sm text-gray-500">Monitor, review, and manually verify customer KYC applications</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search case ID or customer..."
              className="pl-9 pr-4 py-1.5 text-sm border rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <button className="flex items-center space-x-1.5 px-3 py-1.5 border rounded-lg text-sm text-gray-600 hover:bg-gray-50">
            <Filter className="w-4 h-4" /> <span>Filter</span>
          </button>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 border-b text-gray-600 font-medium">
            <tr>
              <th className="py-3 px-4">Case Number</th>
              <th className="py-3 px-4">Customer</th>
              <th className="py-3 px-4">Document</th>
              <th className="py-3 px-4">Face Confidence</th>
              <th className="py-3 px-4">Submitted</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 text-gray-700">
            {cases.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50/50">
                <td className="py-3.5 px-4 font-mono font-medium text-blue-600">{c.caseNumber}</td>
                <td className="py-3.5 px-4 font-semibold">{c.customerName}</td>
                <td className="py-3.5 px-4">{c.docType}</td>
                <td className="py-3.5 px-4 font-semibold text-emerald-600">{c.score}</td>
                <td className="py-3.5 px-4 text-gray-400">{c.submitted}</td>
                <td className="py-3.5 px-4">
                  <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                    c.status === 'Approved' ? 'bg-emerald-50 text-emerald-700' :
                    c.status === 'Rejected' ? 'bg-red-50 text-red-700' : 'bg-amber-50 text-amber-700'
                  }`}>
                    {c.status}
                  </span>
                </td>
                <td className="py-3.5 px-4 text-right">
                  <button
                    onClick={() => setSelectedCase(c)}
                    className="px-3 py-1 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded text-xs font-medium inline-flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" /> Review & Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Case Review & Edit Modal */}
      {selectedCase && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-bold text-gray-900">Review Case: {selectedCase.caseNumber}</h3>
              <button onClick={() => setSelectedCase(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-gray-700 block mb-1">Customer Name</label>
                <input
                  type="text"
                  defaultValue={selectedCase.customerName}
                  className="w-full border rounded p-2 text-sm"
                />
              </div>
              <div>
                <label className="font-semibold text-gray-700 block mb-1">Extracted Masked ID</label>
                <input
                  type="text"
                  defaultValue="XXXX XXXX 9012"
                  className="w-full border rounded p-2 text-sm bg-gray-50"
                  readOnly
                />
              </div>
              <div>
                <label className="font-semibold text-gray-700 block mb-1">Investigator Remarks</label>
                <textarea
                  placeholder="Add approval / rejection notes..."
                  className="w-full border rounded p-2 text-sm h-20"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2 pt-3 border-t">
              <button
                onClick={() => setSelectedCase(null)}
                className="px-4 py-1.5 text-xs text-red-600 hover:bg-red-50 rounded font-medium flex items-center gap-1"
              >
                <XCircle className="w-4 h-4" /> Reject Case
              </button>
              <button
                onClick={() => setSelectedCase(null)}
                className="px-4 py-1.5 text-xs bg-emerald-600 hover:bg-emerald-700 text-white rounded font-medium flex items-center gap-1"
              >
                <CheckCircle className="w-4 h-4" /> Approve Case
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};