import React, { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, Clock, ShieldCheck, Headphones, Info } from 'lucide-react';
import { useAuth } from '../../../context/AuthContext';
import { kycApi } from '../../../services/kycService';

export const Step4Processing = () => {
  const { caseData } = useAuth();
  const [timelineStatus, setTimelineStatus] = useState({
    docUpload: 'COMPLETED',
    docScan: 'COMPLETED',
    docValidation: 'COMPLETED',
    biometric: 'COMPLETED',
    crossVerification: 'IN_PROGRESS',
    compliance: 'PENDING',
    finalizing: 'PENDING'
  });

  // Polling simulation every 5 seconds
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const res = await kycApi.pollStatus(caseData?.KycCaseId || 1024);
        if (res.progress >= 75) {
          setTimelineStatus((prev) => ({
            ...prev,
            crossVerification: 'COMPLETED',
            compliance: 'IN_PROGRESS'
          }));
        }
      } catch (err) {
        console.error("Polling error", err);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [caseData]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Processing Your KYC</h2>
          <p className="text-gray-500 text-sm mt-1">
            Your documents and biometric details have been successfully submitted. We are now processing your KYC. This may take a few minutes. You will be notified once the verification is complete.
          </p>
        </div>

        {/* Timeline */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-6">
          {[
            { id: 'docUpload', title: "Document Upload", desc: "Aadhaar card uploaded successfully", time: "10:12 AM" },
            { id: 'docScan', title: "Document Scan & OCR", desc: "Information extracted successfully", time: "10:12 AM" },
            { id: 'docValidation', title: "Document Validation", desc: "Authenticity, tampering and expiry check completed", time: "10:13 AM" },
            { id: 'biometric', title: "Biometric Verification", desc: "Liveness detection and face match completed", time: "10:15 AM" },
            { id: 'crossVerification', title: "Data Cross-Verification", desc: "Verifying details with authorized sources (e.g. UIDAI)", time: "10:16 AM" },
            { id: 'compliance', title: "Compliance & Risk Checks", desc: "Running regulatory and risk assessment checks", time: "--:--" },
            { id: 'finalizing', title: "Finalizing KYC", desc: "Preparing your KYC profile", time: "--:--" },
          ].map((item, index) => {
            const status = timelineStatus[item.id];
            return (
              <div key={item.id} className="flex items-start justify-between relative">
                {index < 6 && (
                  <div className="absolute left-3.5 top-8 bottom-0 w-0.5 bg-gray-200 -z-0 h-10" />
                )}
                <div className="flex items-start space-x-4 z-10">
                  <div className="mt-0.5">
                    {status === 'COMPLETED' ? (
                      <CheckCircle2 className="w-7 h-7 text-emerald-600 bg-white" />
                    ) : status === 'IN_PROGRESS' ? (
                      <Loader2 className="w-7 h-7 text-blue-600 animate-spin bg-white" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-xs text-gray-500">
                        &bull;
                      </div>
                    )}
                  </div>
                  <div>
                    <h5 className="font-semibold text-gray-800 text-sm">{item.title}</h5>
                    <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
                  </div>
                </div>

                <div className="text-right">
                  {status === 'COMPLETED' && (
                    <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-medium">
                      Completed
                    </span>
                  )}
                  {status === 'IN_PROGRESS' && (
                    <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-medium">
                      In Progress
                    </span>
                  )}
                  {status === 'PENDING' && (
                    <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded font-medium">
                      Pending
                    </span>
                  )}
                  <span className="text-[11px] text-gray-400 block mt-1">{item.time}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Details Panel */}
      <div className="space-y-4">
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-start space-x-3">
          <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-900 leading-relaxed">
            <span className="font-semibold block text-sm">Processing in Progress</span>
            Please do not close this page. We will notify you once the processing is complete.
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-3">
          <h4 className="font-semibold text-gray-900 text-sm">Application Details</h4>
          <div className="text-xs space-y-2.5">
            <div className="flex justify-between">
              <span className="text-gray-400">KYC Reference ID</span>
              <span className="font-semibold text-gray-800">{caseData?.KycNumber || "KYC-2026-000123"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Submitted On</span>
              <span className="text-gray-800">04 Oct 2026 10:18 AM</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">KYC Type</span>
              <span className="text-gray-800">New (Manual Upload)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Current Status</span>
              <span className="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded text-[11px]">
                Processing
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Estimated Time</span>
              <span className="text-gray-800">2 - 5 minutes</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-2">
          <div className="flex items-center space-x-2 text-gray-900 font-semibold text-sm">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <h4>Your Information is Secure</h4>
          </div>
          <p className="text-xs text-gray-500 leading-relaxed">
            Your documents and biometric data are processed using secure and encrypted channels in compliance with regulatory requirements.
          </p>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-2">
          <div className="flex items-center space-x-2 text-gray-900 font-semibold text-sm">
            <Headphones className="w-4 h-4 text-blue-600" />
            <h4>Need Help?</h4>
          </div>
          <p className="text-xs text-gray-500">If you have any questions, please contact our support team.</p>
          <button className="text-xs text-blue-600 font-semibold hover:underline">Contact Support</button>
        </div>
      </div>
    </div>
  );
};