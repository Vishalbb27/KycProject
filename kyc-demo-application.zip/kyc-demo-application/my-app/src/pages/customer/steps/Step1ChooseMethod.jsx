import React from 'react';
import { Landmark, Cloud, FileUp, CheckCircle, Info, Shield, Zap, KeyRound, Lock } from 'lucide-react';
import { useKyc } from '../../../context/KycContext';

export const Step1ChooseMethod = ({ onNext }) => {
  const { kycState, updateKyc } = useKyc();

  const handleSelect = (method) => {
    updateKyc({ method });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-3 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Complete Your KYC / eKYC</h2>
          <p className="text-gray-500 text-sm mt-1">
            Choose how you want to complete your KYC. You can fetch your details from government sources or upload your documents manually.
          </p>
        </div>

        {/* Method Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* CKYC */}
          <div className="border border-gray-200 rounded-xl p-5 bg-white opacity-70 relative">
            <span className="absolute top-3 right-3 text-xs bg-blue-50 text-blue-600 font-semibold px-2 py-0.5 rounded">
              ★ Recommended
            </span>
            <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 mb-3">
              <Landmark className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-gray-800">CKYC</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Fetch your KYC details from Central KYC Registry (CKYC)</p>
            <ul className="text-xs space-y-2 text-gray-600">
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Quick and hassle-free</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Auto fetches your verified details</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Reduces document upload</li>
            </ul>
          </div>

          {/* DigiLocker */}
          <div className="border border-gray-200 rounded-xl p-5 bg-white opacity-70">
            <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center text-purple-600 mb-3">
            <Cloud className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-gray-800">DigiLocker</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Fetch your documents from DigiLocker (Aadhaar, PAN, etc.)</p>
            <ul className="text-xs space-y-2 text-gray-600">
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Secure and verified documents</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Supports Aadhaar, PAN, etc.</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Faster KYC completion</li>
            </ul>
          </div>

          {/* Manual Upload */}
          <div 
            onClick={() => handleSelect('MANUAL')}
            className={`border-2 rounded-xl p-5 bg-white cursor-pointer transition-all shadow-sm ${
              kycState.method === 'MANUAL' ? 'border-blue-600 ring-2 ring-blue-50' : 'border-gray-200'
            }`}
          >
            <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 mb-3">
              <FileUp className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-gray-800">Manual Upload</h3>
            <p className="text-xs text-gray-500 mt-1 mb-4">Upload your documents manually</p>
            <ul className="text-xs space-y-2 text-gray-600">
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Upload files from your device</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Strictly PNG documents</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Azure AI verification enabled</li>
            </ul>
          </div>
        </div>

        {/* Documents info card */}
        <div className="bg-blue-50/70 border border-blue-100 rounded-xl p-4 flex items-start space-x-3">
          <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-900 leading-relaxed">
            <span className="font-semibold block text-sm">Documents you may need</span>
            Commonly accepted documents: Aadhaar Card, PAN Card, Passport, Driving License, etc. You will need to upload the required documents and complete biometric verification in the next steps.
          </div>
        </div>

        <div className="flex justify-between items-center pt-4 border-t border-gray-200">
          <button className="px-5 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
          <button
            onClick={onNext}
            className="px-6 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg"
          >
            Next &gt;
          </button>
        </div>
      </div>

      {/* Right Column: Benefits */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 h-fit space-y-5">
        <h4 className="font-semibold text-gray-900 text-sm">Why complete KYC?</h4>
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <Shield className="w-4 h-4 text-emerald-600 mt-1" />
            <div>
              <p className="text-xs font-semibold text-gray-800">Secure and compliant process</p>
              <p className="text-xs text-gray-500">Your data is protected and encrypted</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <Zap className="w-4 h-4 text-blue-600 mt-1" />
            <div>
              <p className="text-xs font-semibold text-gray-800">Faster onboarding</p>
              <p className="text-xs text-gray-500">Complete your KYC in minutes</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <KeyRound className="w-4 h-4 text-purple-600 mt-1" />
            <div>
              <p className="text-xs font-semibold text-gray-800">Access all services</p>
              <p className="text-xs text-gray-500">Unlock full benefits and features</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <Lock className="w-4 h-4 text-amber-600 mt-1" />
            <div>
              <p className="text-xs font-semibold text-gray-800">Your information is safe</p>
              <p className="text-xs text-gray-500">We follow strict security and privacy standards</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};