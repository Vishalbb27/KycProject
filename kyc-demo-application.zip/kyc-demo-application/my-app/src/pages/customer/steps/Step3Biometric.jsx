import React, { useRef, useState } from 'react';
import Webcam from 'react-webcam';
import { CheckCircle, ShieldCheck, Eye, EyeOff, Laptop, MapPin, Calendar, Camera } from 'lucide-react';
import { useKyc } from '../../../context/KycContext';
import { useAuth } from '../../../context/AuthContext';
import { kycApi } from '../../../services/kycService';

export const Step3Biometric = ({ onNext, onBack }) => {
  const { kycState, updateKyc } = useKyc();
  const { caseData } = useAuth();
  const webcamRef = useRef(null);

  const [maskedView, setMaskedView] = useState({
    docNum: false,
    name: false,
    dob: false,
    ip: false
  });
  const [submitting, setSubmitting] = useState(false);

  // Safely get extracted data, fallback to empty object if undefined
  const extData = kycState.extractedData || {};

  // Dynamic Masking Helper
  const maskText = (text, type) => {
    if (!text) return '****';
    if (type === 'doc') {
      // Show only last 4 characters, mask the rest
      return text.slice(-4).padStart(text.length, '*');
    }
    if (type === 'name') {
      // Show first letter of each word, mask the rest
      return text.split(' ').map(word => word.charAt(0) + '*'.repeat(Math.max(word.length - 1, 0))).join(' ');
    }
    if (type === 'date') {
      // Replace all digits with asterisks
      return text.replace(/\d/g, '*');
    }
    return text;
  };

  const captureSelfie = () => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      updateKyc({ selfieImage: imageSrc });
    }
  };

  const handleSubmitKyc = async () => {
    setSubmitting(true);
    try {
      await kycApi.submitKyc(caseData?.KycCaseId || 1024, {
        biometricCompleted: true,
        livenessScore: kycState.livenessScore
      });
      updateKyc({ submitted: true });
      onNext();
    } catch (err) {
      console.error("KYC Submission error:", err);
      onNext();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Biometric Verification Completed</h2>
          <p className="text-gray-500 text-sm mt-1">
            Your biometric verification has been completed successfully. Below are the verification results.
          </p>
        </div>
        <div className="bg-emerald-50 border border-emerald-200 rounded-lg px-4 py-2 flex items-center space-x-2">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <div className="text-xs text-emerald-800">
            <span className="font-bold block">Biometric Verification Successful</span>
            Your identity has been verified and matched with the uploaded document.
          </div>
        </div>
      </div>

      {/* Grid of Results */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Verification Timing Results */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4">
          <h4 className="font-semibold text-gray-900 text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" /> Verification Results
          </h4>
          <div className="space-y-3 text-xs">
            {[
              { title: "Document Scan & OCR", desc: "Document scanned and information verified", time: "00:12" },
              { title: "Document Authenticity Check", desc: "Checked for tampering, forgery and validity", time: "00:08" },
              { title: "Liveness Detection", desc: "Verified that you are a real person", time: "00:15" },
              { title: "Face Match", desc: "Face matched with document photo", time: "00:10" },
              { title: "Quality Check", desc: "Image quality, lighting and pose verified", time: "00:06" },
            ].map((item, idx) => (
              <div key={idx} className="flex justify-between items-start border-b border-gray-100 pb-2">
                <div>
                  <p className="font-semibold text-gray-800">{item.title}</p>
                  <p className="text-gray-400 text-[11px]">{item.desc}</p>
                </div>
                <div className="text-right">
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Completed
                  </span>
                  <span className="text-gray-400 text-[10px]">{item.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Selfie / Webcam Capture */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 flex flex-col items-center justify-between">
          <h4 className="font-semibold text-gray-900 text-sm self-start mb-2">Captured Selfie</h4>
          <div className="w-full h-48 rounded-lg overflow-hidden relative bg-black flex items-center justify-center">
            {kycState.selfieImage ? (
              <img src={kycState.selfieImage} alt="Selfie" className="w-full h-full object-cover" />
            ) : (
              <Webcam
                ref={webcamRef}
                audio={false}
                screenshotFormat="image/png"
                className="w-full h-full object-cover"
              />
            )}
          </div>
          <div className="mt-3 w-full">
            {!kycState.selfieImage ? (
              <button
                onClick={captureSelfie}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2"
              >
                <Camera className="w-4 h-4" /> Capture Photo
              </button>
            ) : (
              <div className="bg-emerald-50 rounded-lg p-2.5 flex items-center justify-center space-x-2 text-xs text-emerald-800">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Real Person Verified &bull; Liveness score: <strong>{kycState.livenessScore}%</strong></span>
              </div>
            )}
          </div>
        </div>

        {/* Face Match Result */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 flex flex-col justify-between">
          <h4 className="font-semibold text-gray-900 text-sm">Face Match Result</h4>
          <div className="grid grid-cols-2 gap-3 my-2">
            <div className="text-center">
              <span className="text-[11px] text-gray-500 mb-1 block">Live Selfie</span>
              <div className="w-full h-28 bg-gray-100 rounded-lg overflow-hidden border">
                {kycState.selfieImage ? (
                  <img src={kycState.selfieImage} alt="Match 1" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">Selfie</div>
                )}
              </div>
            </div>
            <div className="text-center">
              <span className="text-[11px] text-gray-500 mb-1 block">Document Photo</span>
              <div className="w-full h-28 bg-gray-100 rounded-lg overflow-hidden border">
                {kycState.frontImage ? (
                  <img src={kycState.frontImage} alt="Match 2" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-gray-400">Doc Photo</div>
                )}
              </div>
            </div>
          </div>
          <div className="bg-emerald-50 rounded-lg p-2.5 flex items-center justify-center space-x-2 text-xs text-emerald-800">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>Face Match Successful &bull; <strong>{kycState.faceMatchScore}%</strong> match confidence</span>
          </div>
        </div>
      </div>

      {/* Bottom Row Details: Masked Data, Security, Verification */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Document Details & DYNAMIC Masked Information */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="font-semibold text-gray-900 text-sm">Extracted Information (Masked)</h4>
            <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-medium flex items-center gap-1">
              <CheckCircle className="w-3 h-3" /> Verified
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-gray-100">
              <span className="text-gray-400">Document Type</span>
              <span className="font-medium text-gray-800">{extData.document_type?.replace(/_/g, ' ') || "Identity Document"}</span>
            </div>
            
            <div className="flex justify-between items-center py-1 border-b border-gray-100">
              <span className="text-gray-400">Document Number</span>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-gray-800">
                  {maskedView.docNum ? extData.document_number : maskText(extData.document_number, 'doc')}
                </span>
                <button onClick={() => setMaskedView(v => ({ ...v, docNum: !v.docNum }))} className="text-blue-600 hover:text-blue-800">
                  {maskedView.docNum ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            
            <div className="flex justify-between items-center py-1 border-b border-gray-100">
              <span className="text-gray-400">Full Name</span>
              <div className="flex items-center space-x-2">
                <span>{maskedView.name ? extData.full_name : maskText(extData.full_name, 'name')}</span>
                <button onClick={() => setMaskedView(v => ({ ...v, name: !v.name }))} className="text-blue-600 hover:text-blue-800">
                  {maskedView.name ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            
            <div className="flex justify-between items-center py-1">
              <span className="text-gray-400">Date of Birth</span>
              <div className="flex items-center space-x-2">
                <span>{maskedView.dob ? extData.date_of_birth : maskText(extData.date_of_birth, 'date')}</span>
                <button onClick={() => setMaskedView(v => ({ ...v, dob: !v.dob }))} className="text-blue-600 hover:text-blue-800">
                  {maskedView.dob ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Security Checks */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-3">
          <h4 className="font-semibold text-gray-900 text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" /> Security Checks
          </h4>
          <ul className="text-xs space-y-2.5 text-gray-700">
            <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> No deepfake detected</li>
            <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> No spoofing detected</li>
            <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Image quality is good</li>
            <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Device and environment verified</li>
          </ul>
        </div>

        {/* Verification Metadata */}
        <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-3">
          <h4 className="font-semibold text-gray-900 text-sm">Verification Details</h4>
          <div className="text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 flex items-center gap-1"><Laptop className="w-3 h-3" /> Device</span>
              <span className="text-gray-800 font-medium">Browser (Chrome)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">IP Address</span>
              <div className="flex items-center gap-1 font-mono">
                <span>{maskedView.ip ? "122.161.45.10" : "122.***.**.10"}</span>
                <button onClick={() => setMaskedView(v => ({ ...v, ip: !v.ip }))} className="text-blue-600">
                  <Eye className="w-3 h-3" />
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 flex items-center gap-1"><Calendar className="w-3 h-3" /> Date & Time</span>
              <span className="text-gray-800">{new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' })}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 flex items-center gap-1"><MapPin className="w-3 h-3" /> Location</span>
              <span className="text-gray-800">Bengaluru, India</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Nav */}
      <div className="flex justify-between items-center pt-4 border-t border-gray-200">
        <button onClick={onBack} className="px-5 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">
          Back
        </button>
        <button
          onClick={handleSubmitKyc}
          disabled={submitting}
          className="px-6 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg flex items-center gap-2"
        >
          {submitting ? "Submitting..." : "Submit KYC \u2192"}
        </button>
      </div>
    </div>
  );
};