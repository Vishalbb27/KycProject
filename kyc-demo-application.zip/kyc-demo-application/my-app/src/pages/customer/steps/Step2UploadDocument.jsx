import React, { useState } from 'react';
import { UploadCloud, CheckCircle, Eye, Trash2, ShieldCheck } from 'lucide-react';
import { useKyc } from '../../../context/KycContext';
import { useAuth } from '../../../context/AuthContext';
import { kycApi } from '../../../services/kycService';

export const Step2UploadDocument = ({ onNext, onBack }) => {
  const { kycState, updateKyc } = useKyc();
  const { caseData } = useAuth();

  const [uploading, setUploading] = useState(false);
  const [consentChecked, setConsentChecked] = useState(false);
  const [otp, setOtp] = useState('');
  const [rawFiles, setRawFiles] = useState({ front: null, back: null }); 

  const handleFile = async (e, side) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'image/png') {
      alert("Strictly document type should be PNG format.");
      return;
    }

    // 1. Cache the raw File object
    const updatedRawFiles = { ...rawFiles };
    if (side === 'frontImage') updatedRawFiles.front = file;
    if (side === 'backImage') updatedRawFiles.back = file;
    setRawFiles(updatedRawFiles);

    // 2. Read as Base64 for the UI preview
    const reader = new FileReader();
    reader.onload = () => {
      updateKyc({ [side]: reader.result });
    };
    reader.readAsDataURL(file);

    // 3. Fire API only if both images are present
    if (updatedRawFiles.front && updatedRawFiles.back) {
      setUploading(true);
      try {
        const res = await kycApi.uploadDocument({
          case_id: caseData?.KycCaseId || 1024,
          front_png: updatedRawFiles.front,
          back_png: updatedRawFiles.back
        });
        
        updateKyc({
          extractedData: res.data?.extracted_data || kycState.extractedData,
          ruleValidation: res.data?.rule_validation || kycState.ruleValidation,
          documentType: res.data?.document_type || kycState.documentType
        });
      } catch (err) {
        console.error("Document Upload Error:", err);
      } finally {
        setUploading(false);
      }
    }
  };

  const verifyOtp = () => {
    if (otp.length === 6) {
      updateKyc({ otpVerified: true });
    } else {
      alert("Please enter a valid 6-digit OTP");
    }
  };

  // Safely check for any successful API decision (Approved, Passed, Verified, etc.)
  const apiDecision = kycState.ruleValidation?.decision?.toUpperCase() || "";
  const isApproved = apiDecision === "APPROVED" || apiDecision === "PASSED" || apiDecision === "VERIFIED";
  
  const canContinue = isApproved && kycState.otpVerified;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-3 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Upload Your Document & Provide Consent</h2>
          <p className="text-gray-500 text-sm mt-1">
            Please upload your identity document for KYC. Ensure the document is clear, valid and not expired.
          </p>
        </div>

        {/* Section 1: Upload identity document */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-5">
          <div className="flex items-center space-x-3">
            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">1</span>
            <div>
              <h3 className="font-semibold text-gray-800 text-sm">
                {kycState.documentType ? `${kycState.documentType.replace(/_/g, ' ')} (Proof of Identity)` : "Upload Identity Document *"}
              </h3>
              <p className="text-xs text-gray-500">
                Upload the front and back side of your identity document.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Front Side */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-medium text-gray-700">Front Side *</span>
                {uploading ? (
                   <span className="text-amber-600 flex items-center gap-1 font-semibold animate-pulse">Processing AI...</span>
                ) : isApproved ? (
                  <span className="text-emerald-600 flex items-center gap-1 font-semibold"><CheckCircle className="w-3.5 h-3.5" /> Approved</span>
                ) : kycState.frontImage ? (
                  <span className="text-blue-600 flex items-center gap-1 font-semibold">Selected</span>
                ) : null}
              </div>

              {!kycState.frontImage ? (
                <label className="border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 transition-colors bg-gray-50/50">
                  <UploadCloud className="w-8 h-8 text-blue-500 mb-2" />
                  <span className="text-xs font-semibold text-gray-700">Click to upload or drag and drop</span>
                  <span className="text-[11px] text-gray-400 mt-1">Strictly PNG format (Max 5 MB)</span>
                  <input type="file" accept="image/png" className="hidden" onChange={(e) => handleFile(e, 'frontImage')} />
                </label>
              ) : (
                <div className="border rounded-xl p-3 bg-gray-50 space-y-2">
                  <img src={kycState.frontImage} alt="Front preview" className="w-full h-36 object-contain rounded bg-white border" />
                  <div className="flex justify-between items-center pt-1 text-xs">
                    <button type="button" className="text-blue-600 flex items-center gap-1 hover:underline">
                      <Eye className="w-3.5 h-3.5" /> View
                    </button>
                    <button type="button" onClick={() => {
                      updateKyc({ frontImage: null, extractedData: null, ruleValidation: null, documentType: null });
                      setRawFiles(prev => ({ ...prev, front: null }));
                    }} className="text-red-500 flex items-center gap-1 hover:underline">
                      <Trash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Back Side */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-medium text-gray-700">Back Side *</span>
                {uploading ? (
                   <span className="text-amber-600 flex items-center gap-1 font-semibold animate-pulse">Processing AI...</span>
                ) : isApproved ? (
                  <span className="text-emerald-600 flex items-center gap-1 font-semibold"><CheckCircle className="w-3.5 h-3.5" /> Approved</span>
                ) : kycState.backImage ? (
                  <span className="text-blue-600 flex items-center gap-1 font-semibold">Selected</span>
                ) : null}
              </div>

              {!kycState.backImage ? (
                <label className="border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 transition-colors bg-gray-50/50">
                  <UploadCloud className="w-8 h-8 text-blue-500 mb-2" />
                  <span className="text-xs font-semibold text-gray-700">Click to upload or drag and drop</span>
                  <span className="text-[11px] text-gray-400 mt-1">Strictly PNG format (Max 5 MB)</span>
                  <input type="file" accept="image/png" className="hidden" onChange={(e) => handleFile(e, 'backImage')} />
                </label>
              ) : (
                <div className="border rounded-xl p-3 bg-gray-50 space-y-2">
                  <img src={kycState.backImage} alt="Back preview" className="w-full h-36 object-contain rounded bg-white border" />
                  <div className="flex justify-between items-center pt-1 text-xs">
                    <button type="button" className="text-blue-600 flex items-center gap-1 hover:underline">
                      <Eye className="w-3.5 h-3.5" /> View
                    </button>
                    <button type="button" onClick={() => {
                      updateKyc({ backImage: null, extractedData: null, ruleValidation: null, documentType: null });
                      setRawFiles(prev => ({ ...prev, back: null }));
                    }} className="text-red-500 flex items-center gap-1 hover:underline">
                      <Trash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Section 2: Consent & OTP */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center space-x-3">
            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">2</span>
            <h3 className="font-semibold text-gray-800 text-sm">Provide Consent & Verify via OTP *</h3>
          </div>

          <div className="pl-9 space-y-3">
            <label className="flex items-start space-x-2 text-xs text-gray-600 cursor-pointer">
              <input
                type="checkbox"
                checked={consentChecked}
                onChange={(e) => setConsentChecked(e.target.checked)}
                className="mt-0.5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span>We need your consent to authorize the document from the platform to verify your identity.</span>
            </label>

            {!kycState.otpVerified ? (
              consentChecked && (
                <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                  <label className="text-xs font-semibold text-gray-700 block">Enter OTP *</label>
                  <div className="flex items-center space-x-3">
                    <input
                      type="text"
                      maxLength={6}
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="Enter 6-digit OTP"
                      className="px-3 py-1.5 text-sm border rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 w-56"
                    />
                    <button type="button" onClick={verifyOtp} className="px-4 py-1.5 text-xs bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg">
                      Verify OTP
                    </button>
                  </div>
                </div>
              )
            ) : (
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs text-emerald-800">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span className="font-semibold block">OTP Verified Successfully</span>
                    Your consent has been recorded.
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between items-center pt-4 border-t border-gray-200">
          <button type="button" onClick={onBack} className="px-5 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">Back</button>
          <button
            type="button"
            disabled={!canContinue || uploading}
            onClick={onNext}
            className={`px-6 py-2 text-sm font-medium rounded-lg flex items-center gap-2 ${
              canContinue && !uploading ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            {uploading ? "Processing AI..." : "Continue to Biometric Verification \u2192"}
          </button>
        </div>
      </div>

      {/* Right Column: AI Extraction */}
      <div className="space-y-4">
        {uploading && (
          <div className="bg-white border border-gray-200 rounded-xl p-5 text-center text-sm text-blue-600 font-semibold shadow-sm animate-pulse">
            Analyzing Documents...
          </div>
        )}
        
        {kycState.extractedData && !uploading && (
          <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4 shadow-sm">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
              <h4 className="font-semibold text-gray-900 text-sm">Extraction Summary</h4>
            </div>
            <div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-semibold text-gray-800">Extracted Information</span>
                <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> Verified
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-400">Document Type</span>
                  <span className="font-medium text-gray-800">{kycState.extractedData.document_type?.replace(/_/g, ' ') || "Identity Document"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Document Number</span>
                  <span className="font-medium text-gray-800">{kycState.extractedData.document_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Full Name</span>
                  <span className="font-medium text-gray-800">{kycState.extractedData.full_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Date of Birth</span>
                  <span className="font-medium text-gray-800">{kycState.extractedData.date_of_birth}</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {!kycState.extractedData && !uploading && (
          <div className="bg-white border border-gray-200 rounded-xl p-5 space-y-4">
            <h4 className="font-semibold text-gray-900 text-sm">Document Guidelines</h4>
            <ul className="text-xs space-y-2 text-gray-600">
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> Ensure all corners are visible</li>
              <li className="flex items-center"><CheckCircle className="w-3.5 h-3.5 text-emerald-500 mr-2" /> No glare, blur or cropped images</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};