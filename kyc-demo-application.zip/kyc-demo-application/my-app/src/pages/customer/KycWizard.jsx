import React from 'react';
import { Stepper } from '../../components/common/Stepper';
import { Step1ChooseMethod } from './steps/Step1ChooseMethod';
import { Step2UploadDocument } from './steps/Step2UploadDocument';
import { Step3Biometric } from './steps/Step3Biometric';
import { Step4Processing } from './steps/Step4Processing';
import { useKyc } from '../../context/KycContext';

export const KycWizard = () => {
  const { kycState, updateKyc } = useKyc();

  const handleNext = () => {
    updateKyc({ currentStep: Math.min(kycState.currentStep + 1, 4) });
  };

  const handleBack = () => {
    updateKyc({ currentStep: Math.max(kycState.currentStep - 1, 1) });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-4">
      <Stepper currentStep={kycState.currentStep} />
      {kycState.currentStep === 1 && <Step1ChooseMethod onNext={handleNext} />}
      {kycState.currentStep === 2 && <Step2UploadDocument onNext={handleNext} onBack={handleBack} />}
      {kycState.currentStep === 3 && <Step3Biometric onNext={handleNext} onBack={handleBack} />}
      {kycState.currentStep === 4 && <Step4Processing />}
    </div>
  );
};