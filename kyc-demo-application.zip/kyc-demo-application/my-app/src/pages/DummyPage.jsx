import React from 'react';

export const DummyPage = ({ title }) => (
  <div className="p-8 max-w-4xl mx-auto">
    <div className="bg-white border rounded-xl p-8 text-center space-y-3">
      <h2 className="text-xl font-bold text-gray-800">{title}</h2>
      <p className="text-xs text-gray-400">This module is under construction and will be wired with backend services.</p>
    </div>
  </div>
);