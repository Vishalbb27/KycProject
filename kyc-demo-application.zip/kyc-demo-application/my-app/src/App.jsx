import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { KycProvider } from './context/KycContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { Login } from './pages/Login';
import { KycWizard } from './pages/customer/KycWizard';
import { InvestigatorDashboard } from './pages/Investigator/InvestigatorDashboard';
import { DummyPage } from './pages/DummyPage';

const ProtectedLayout = ({ children, allowedRole }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRole && user.role !== allowedRole) return <Navigate to="/login" replace />;

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
      <Header />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <KycProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route
              path="/kyc"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <KycWizard />
                </ProtectedLayout>
              }
            />
            <Route
              path="/dashboard"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <DummyPage title="Customer Dashboard" />
                </ProtectedLayout>
              }
            />
            <Route
              path="/applications"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <DummyPage title="My Applications" />
                </ProtectedLayout>
              }
            />
            <Route
              path="/documents"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <DummyPage title="Documents Archive" />
                </ProtectedLayout>
              }
            />
            <Route
              path="/notifications"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <DummyPage title="Notifications Center" />
                </ProtectedLayout>
              }
            />
            <Route
              path="/support"
              element={
                <ProtectedLayout allowedRole="CUSTOMER">
                  <DummyPage title="Support Desk" />
                </ProtectedLayout>
              }
            />
            <Route
              path="/investigator"
              element={
                <ProtectedLayout allowedRole="INVESTIGATOR">
                  <InvestigatorDashboard />
                </ProtectedLayout>
              }
            />
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </BrowserRouter>
      </KycProvider>
    </AuthProvider>
  );
}