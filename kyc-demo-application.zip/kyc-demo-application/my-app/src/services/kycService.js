import axios from 'axios';
import { msalInstance } from '../context/AuthContext';
import { loginRequest } from '../config/msalConfig';

const client = axios.create({
  baseURL: '/api/v1',
});

// Automatically attach the MSAL Bearer token to every request
client.interceptors.request.use(
  async (config) => {
    const accounts = msalInstance.getAllAccounts();
    
    if (accounts.length > 0) {
      try {
        // Attempt to grab the token silently from the browser cache
        const response = await msalInstance.acquireTokenSilent({
          ...loginRequest,
          account: accounts[0]
        });
        console.log("Acquired token silently:", response.accessToken);
        
        // Attach the token to the Authorization header
        config.headers.Authorization = `Bearer ${response.accessToken}`;
      } catch (error) {
        console.warn("Silent token acquisition failed. User may need to re-login.", error);
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const kycApi = {
  initCase: async (payload) => {
    const response = await client.post('/cases/init', payload);
    return response.data; 
  },

  uploadDocument: async ({ case_id, front_png, back_png, document_id }) => {
    const formData = new FormData();
    
    // 1. Append IDs as strict integers
    formData.append('case_id', Number(case_id));
    if (document_id) {
      formData.append('document_id', Number(document_id));
    }

    // 2. Append the files using the EXACT parameter names the backend expects
    if (front_png) {
      formData.append('front_image', front_png); 
    }
    
    if (back_png) {
      formData.append('back_image', back_png);
    }

    // Fire the request
    const response = await client.post('/documents/upload', formData);
    return response.data;
  },

  // Mocked endpoints for now
  submitKyc: async (caseId, payload) => {
    return Promise.resolve({ success: true, message: "KYC submitted successfully" });
  },
  pollStatus: async (caseId) => {
    return Promise.resolve({ stage: "Data Cross-Verification", progress: 75, isCompleted: false });
  },
  getInvestigatorCases: async () => {
    return Promise.resolve([]);
  }
};