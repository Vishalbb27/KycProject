import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: 'http://localhost:8000', // CHANGE THIS to your actual backend URL/port
        changeOrigin: true,
        secure: false,
      }
    }
  }
})